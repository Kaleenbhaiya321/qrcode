<?php
/**
 * TEXT - Enhanced with animations and consistent UI
 */
if (qrcdr()->getConfig('text') == true) { ?>
    <div class="tab-pane fade <?php if ($getsection === "#text") echo "show active"; ?>" id="text">
        <div class="card border-info shadow-sm animate__animated animate__fadeIn">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0">
                    <i class="fas fa-align-left mr-2"></i>
                    <?php echo qrcdr()->getString('text'); ?>
                </h4>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <label class="font-weight-bold text-primary">
                        <i class="fas fa-comment-dots mr-1"></i>
                        <?php echo qrcdr()->getString('message'); ?>
                    </label>
                    <textarea rows="5" name="data" 
                        class="form-control animate__animated animate__pulse animate__delay-1s"
                        required="required" 
                        maxlength="1000"
                        onfocus="this.classList.add('shadow')"
                        onblur="this.classList.remove('shadow')"
                        placeholder="Enter Your Message Here"></textarea>
                    <div class="d-flex justify-content-between mt-2">
                        <small class="form-text text-primary">
                            <i class="fas fa-info-circle mr-1"></i>
                            Max 1000 Characters Allowed
                        </small>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script>
        // Character counter functionality
        document.addEventListener('DOMContentLoaded', function() {
            const textarea = document.querySelector('#text textarea');
            const counter = document.querySelector('#text .current-count');
            
            if (textarea && counter) {
                textarea.addEventListener('input', function() {
                    const count = this.value.length;
                    counter.textContent = count;
                    
                    // Animation when typing
                    if (count > 0) {
                        counter.classList.add('animate__animated', 'animate__headShake');
                        setTimeout(() => counter.classList.remove('animate__animated', 'animate__headShake'), 1000);
                    }
                    
                    // Color change when approaching limit
                    if (count > 900) {
                        counter.style.color = '#dc3545';
                    } else {
                        counter.style.color = '#17a2b8';
                    }
                });
            }
        });
    </script>
    <?php
}