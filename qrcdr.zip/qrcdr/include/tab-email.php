<?php
/**
 * E-MAIL - Enhanced with animations and consistent UI
 */
if (qrcdr()->getConfig('email') == true) { ?>
    <div class="tab-pane fade <?php if ($getsection === "#email") echo "show active"; ?>" id="email">
        <div class="card border-danger shadow-sm animate__animated animate__fadeIn">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0">
                    <i class="fas fa-envelope mr-2"></i>
                    <?php echo qrcdr()->getString('email'); ?>
                </h4>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 form-group">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-at mr-1"></i>
                            <?php echo qrcdr()->getString('send_to'); ?>
                        </label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-user-circle"></i>
                                </span>
                            </div>
                            <input type="email" name="mailto" 
                                class="form-control animate__animated animate__pulse animate__delay-1s"
                                placeholder="recipient@example.com" 
                                required="required"
                                onfocus="this.classList.add('shadow')"
                                onblur="this.classList.remove('shadow')">
                        </div>
                    </div>
                    
                    <div class="col-md-6 form-group">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-tag mr-1"></i>
                            <?php echo qrcdr()->getString('subject'); ?>
                        </label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-heading"></i>
                                </span>
                            </div>
                            <input type="text" name="subject" 
                                class="form-control animate__animated animate__pulse animate__delay-1s"
                                placeholder="Email Subject Placeholder" 
                                required="required"
                                onfocus="this.classList.add('shadow')"
                                onblur="this.classList.remove('shadow')">
                        </div>
                    </div>
                    
                    <div class="col-12 form-group">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-align-left mr-1"></i>
                            <?php echo qrcdr()->getString('text'); ?>
                        </label>
                        <textarea name="body" 
                            class="form-control animate__animated animate__pulse animate__delay-1s"
                            required="required" 
                            maxlength="1000"
                            rows="5"
                            onfocus="this.classList.add('shadow')"
                            onblur="this.classList.remove('shadow')"
                            placeholder="Email Body Placeholder"></textarea>
                        <div class="d-flex justify-content-between mt-2">
                            <small class="form-text text-primary">
                                <i class="fas fa-info-circle mr-1"></i>
                                Max 1000 Characters Allowed
                            </small>
                            
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>

    <style>
        /* Custom styling for email inputs */
        #email input, 
        #email textarea {
            transition: all 0.3s ease;
            border-left: 3px solid #dc3545;
        }
        
        #email input:focus,
        #email textarea:focus {
            border-color: #bd2130;
            box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.25);
        }
        
        #email .character-counter .current-count {
            color: #dc3545;
        }
        
        #email .input-group-text {
            transition: all 0.3s;
        }
        
        #email .input-group:focus-within .input-group-text {
            background-color: #dc3545;
            color: white;
        }
    </style>

    <script>
        // Character counter functionality for email body
        document.addEventListener('DOMContentLoaded', function() {
            const textarea = document.querySelector('#email textarea[name="body"]');
            const counter = document.querySelector('#email .current-count');
            
            if (textarea && counter) {
                textarea.addEventListener('input', function() {
                    const count = this.value.length;
                    counter.textContent = count;
                    
                    // Animation when typing
                    if (count > 0) {
                        counter.classList.add('animate__animated', 'animate__headShake');
                        setTimeout(() => counter.classList.remove('animate__animated', 'animate__headShake'), 1000);
                    }
                    
                    // Color change when approaching limit
                    if (count > 900) {
                        counter.style.color = '#dc3545';
                    } else {
                        counter.style.color = '#dc3545';
                    }
                });
            }
            
            // Email validation animation
            const emailInput = document.querySelector('#email input[type="email"]');
            if (emailInput) {
                emailInput.addEventListener('blur', function() {
                    if (this.value && !this.checkValidity()) {
                        this.classList.add('animate__animated', 'animate__shakeX');
                        setTimeout(() => this.classList.remove('animate__animated', 'animate__shakeX'), 1000);
                    }
                });
            }
        });
    </script>
    <?php
}