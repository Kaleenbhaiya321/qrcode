<?php
/**
 * SKYPE - Enhanced with animations and consistent UI
 */
if (qrcdr()->getConfig('skype') == true) { ?>
<div class="tab-pane fade <?php if ($getsection === "#skype") echo "show active"; ?>" id="skype">
    <div class="card border-primary shadow-sm animate__animated animate__fadeIn">
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0">
                <i class="fab fa-skype mr-2"></i>
                Skype
            </h4>
        </div>
        <div class="card-body">
            <div class="form-group">
                <label class="font-weight-bold text-primary mb-2">
                    <i class="fas fa-comments mr-1"></i>
                    Action Type
                </label>
                <div class="btn-group btn-group-toggle w-100 animate__animated animate__pulse animate__delay-1s" data-toggle="buttons">
                    <label class="btn btn-outline-primary active">
                        <input type="radio" name="skypeType" value="chat" checked autocomplete="off">
                        <i class="fas fa-comment-dots mr-1"></i>
                        <?php echo qrcdr()->getString('chat'); ?>
                    </label>
                    <label class="btn btn-outline-primary">
                        <input type="radio" name="skypeType" value="call" autocomplete="off">
                        <i class="fas fa-phone-alt mr-1"></i>
                        <?php echo qrcdr()->getString('call'); ?>
                    </label>
                </div>
            </div>
            
            <div class="form-group mt-4">
                <label class="font-weight-bold text-primary" for="skype">
                    <i class="fas fa-user-circle mr-1"></i>
                    <?php echo qrcdr()->getString('username'); ?>
                </label>
                <div class="input-group animate__animated animate__pulse animate__delay-1s">
                    <div class="input-group-prepend">
                        <span class="input-group-text bg-light">
                            <i class="fab fa-skype"></i>
                        </span>
                    </div>
                    <input type="text" name="skype" id="skype" 
                        class="form-control" 
                        required="required"
                        placeholder="Enter Skype Username"
                        onfocus="this.parentElement.classList.add('shadow')"
                        onblur="this.parentElement.classList.remove('shadow')" />
                    <div class="input-group-append">
                        <span class="input-group-text bg-light">
                            <i class="fas fa-check-circle text-success d-none" id="skype-valid-icon"></i>
                        </span>
                    </div>
                </div>
                <small class="form-text text-primary mt-1">
                    <i class="fas fa-info-circle mr-1"></i>
                    Enter Ekype Id Without Prefix
                </small>
            </div>
        </div>
        
    </div>
</div>

<style>
    /* Custom styling for Skype inputs */
    #skype input,
    #skype .btn-group {
        transition: all 0.3s ease;
    }
    
    #skype input {
        border-left: 3px solid #007bff;
    }
    
    #skype input:focus {
        border-color: #0062cc;
        box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
    }
    
    #skype .input-group:focus-within .input-group-text {
        background-color: #007bff;
        color: white;
    }
    
    #skype .btn-outline-primary.active {
        background-color: #007bff;
        color: white;
    }
    
    .fa-skype {
        color: #00AFF0;
    }
</style>

<script>
    // Skype functionality
    document.addEventListener('DOMContentLoaded', function() {
        // Username validation
        const skypeInput = document.getElementById('skype');
        const skypeValidIcon = document.getElementById('skype-valid-icon');
        
        if (skypeInput && skypeValidIcon) {
            skypeInput.addEventListener('input', function() {
                if (this.value.length > 3) {
                    skypeValidIcon.classList.remove('d-none');
                    this.classList.add('is-valid');
                    skypeValidIcon.classList.add('animate__animated', 'animate__rubberBand');
                    setTimeout(() => skypeValidIcon.classList.remove('animate__animated', 'animate__rubberBand'), 1000);
                } else {
                    skypeValidIcon.classList.add('d-none');
                    this.classList.remove('is-valid');
                }
            });
        }
        
        // Animate radio buttons on change
        const skypeRadios = document.querySelectorAll('#skype input[name="skypeType"]');
        skypeRadios.forEach(radio => {
            radio.addEventListener('change', function() {
                const label = this.closest('label');
                label.classList.add('animate__animated', 'animate__tada');
                setTimeout(() => label.classList.remove('animate__animated', 'animate__tada'), 1000);
            });
        });
    });
</script>
<?php
}