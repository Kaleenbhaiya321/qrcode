<?php
/**
 * EVENT - Enhanced with animations and consistent UI
 */
if (qrcdr()->getConfig('event') == true) {
    $relative = qrcdr()->relativePath();
    $lang = qrcdr()->getLang();
    $localepath = $relative.'js/tempusdominus/locales/'.$lang.'.js';
    $localdata = file_exists($localepath) ? ' data-locale="'.$lang.'"' : '';
    ?>
    <div class="tab-pane fade <?php if ($getsection === "#event") echo "show active"; ?>" id="event"<?php echo $localdata; ?>>
        <div class="card border-danger shadow-sm animate__animated animate__fadeIn">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0">
                    <i class="fas fa-calendar-alt mr-2"></i>
                    <?php echo qrcdr()->getString('event'); ?>
                </h4>
            </div>
            <div class="card-body">
                <div class="row">
                    <!-- Event Title & Location -->
                    <div class="col-md-6 form-group">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-heading mr-1"></i>
                            <?php echo qrcdr()->getString('event_title'); ?>
                        </label>
                        <div class="input-group animate__animated animate__pulse animate__delay-1s">
                            <div class="input-group-prepend">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-pen"></i>
                                </span>
                            </div>
                            <input type="text" name="eventtitle" 
                                class="form-control" 
                                required="required"
                                placeholder="event_name_placeholder"
                                onfocus="this.parentElement.classList.add('shadow')"
                                onblur="this.parentElement.classList.remove('shadow')">
                        </div>
                    </div>
                    
                    <div class="col-md-6 form-group">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-map-marker-alt mr-1"></i>
                            <?php echo qrcdr()->getString('location'); ?>
                        </label>
                        <div class="input-group animate__animated animate__pulse animate__delay-1s">
                            <div class="input-group-prepend">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-location-arrow"></i>
                                </span>
                            </div>
                            <input type="text" name="eventlocation" 
                                class="form-control"
                                placeholder="event_location_placeholder"
                                onfocus="this.parentElement.classList.add('shadow')"
                                onblur="this.parentElement.classList.remove('shadow')">
                        </div>
                    </div>

                    <!-- Date & Time Pickers -->
                    <div class="col-md-6 form-group">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-clock mr-1"></i>
                            <?php echo qrcdr()->getString('start_time'); ?>
                        </label>
                        <div class="input-group date animate__animated animate__pulse animate__delay-1s" id="eventstart-group" data-target-input="nearest">
                            <div class="input-group-prepend" data-target="#eventstart" data-toggle="datetimepicker">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-calendar-day"></i>
                                </span>
                            </div>
                            <input type="text" class="form-control datetimepicker-input" 
                                id="eventstart" 
                                data-toggle="datetimepicker" 
                                data-target="#eventstart" 
                                data-timestamp="#eventstarttime" 
                                required="required"
                                onfocus="this.parentElement.classList.add('shadow')"
                                onblur="this.parentElement.classList.remove('shadow')"/>
                            <input type="hidden" name="eventstarttime" id="eventstarttime" class="get-timestamp">
                        </div>
                    </div>

                    <div class="col-md-6 form-group">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-clock mr-1"></i>
                            <?php echo qrcdr()->getString('end_time'); ?>
                        </label>
                        <div class="input-group date animate__animated animate__pulse animate__delay-1s" id="eventend-group" data-target-input="nearest">
                            <div class="input-group-prepend" data-target="#eventend" data-toggle="datetimepicker">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-calendar-day"></i>
                                </span>
                            </div>
                            <input type="text" class="form-control datetimepicker-input" 
                                id="eventend" 
                                data-toggle="datetimepicker" 
                                data-target="#eventend" 
                                data-timestamp="#eventendtime"
                                onfocus="this.parentElement.classList.add('shadow')"
                                onblur="this.parentElement.classList.remove('shadow')"/>
                            <input type="hidden" name="eventendtime" id="eventendtime" class="get-timestamp">
                        </div>
                    </div>

                    <!-- Reminder -->
                    <div class="col-md-6 form-group">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-bell mr-1"></i>
                            <?php echo qrcdr()->getString('reminder_before_event'); ?>
                        </label>
                        <div class="input-group animate__animated animate__pulse animate__delay-1s">
                            <div class="input-group-prepend">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-bell"></i>
                                </span>
                            </div>
                            <select class="form-select custom-select" name="eventreminder" id="eventreminder"
                                onfocus="this.parentElement.classList.add('shadow')"
                                onblur="this.parentElement.classList.remove('shadow')">
                                <option value="">No Reminder</option>
                                <option value="PT0M"><?php echo qrcdr()->getString('when_the_event_starts'); ?></option>
                                <option value="-PT5M">5 <?php echo qrcdr()->getString('minutes'); ?></option>
                                <option value="-PT10M">10 <?php echo qrcdr()->getString('minutes'); ?></option>
                                <option value="-PT15M">15 <?php echo qrcdr()->getString('minutes'); ?></option>
                                <option value="-PT30M">30 <?php echo qrcdr()->getString('minutes'); ?></option>
                                <option value="-PT1H">1 <?php echo qrcdr()->getString('hour'); ?></option>
                                <option value="-PT2H">2 <?php echo qrcdr()->getString('hours'); ?></option>
                                <option value="-PT3H">3 <?php echo qrcdr()->getString('hours'); ?></option>
                                <option value="-PT4H">4 <?php echo qrcdr()->getString('hours'); ?></option>
                                <option value="-PT5H">5 <?php echo qrcdr()->getString('hours'); ?></option>
                                <option value="-PT6H">6 <?php echo qrcdr()->getString('hours'); ?></option>
                                <option value="-PT12H">12 <?php echo qrcdr()->getString('hours'); ?></option>
                                <option value="-PT24H">24 <?php echo qrcdr()->getString('hours'); ?></option>
                                <option value="-PT48H">48 <?php echo qrcdr()->getString('hours'); ?></option>
                                <option value="-PT168H">1 <?php echo qrcdr()->getString('week'); ?></option>
                            </select>
                        </div>
                    </div>
                   
                    <!-- Event Link -->
                    <div class="col-md-6 form-group">
                        <label class="font-weight-bold text-primary" for="eventlink">
                            <i class="fas fa-link mr-1"></i>
                            <?php echo qrcdr()->getString('link'); ?>
                        </label>
                        <div class="input-group animate__animated animate__pulse animate__delay-1s">
                            <div class="input-group-prepend">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-external-link-alt"></i>
                                </span>
                            </div>
                            <input type="url" name="eventlink" id="eventlink" 
                                class="form-control" 
                                placeholder="https://"
                                onfocus="this.parentElement.classList.add('shadow')"
                                onblur="this.parentElement.classList.remove('shadow')" />
                        </div>
                    </div>
                   
                    <!-- Notes -->
                    <div class="col-12 form-group">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-sticky-note mr-1"></i>
                            <?php echo qrcdr()->getString('notes'); ?>
                        </label>
                        <textarea rows="3" name="eventnote" 
                            class="form-control animate__animated animate__pulse animate__delay-1s"
                            maxlength="500"
                            placeholder="event notes laceholder"
                            onfocus="this.classList.add('shadow')"
                            onblur="this.classList.remove('shadow')"></textarea>
                        
                    </div>
                </div>
            </div>
            
        </div>
    </div>

    <style>
        /* Custom styling for Event inputs */
        #event input,
        #event select,
        #event textarea {
            transition: all 0.3s ease;
            border-left: 3px solid #dc3545;
        }
        
        #event input:focus,
        #event select:focus,
        #event textarea:focus {
            border-color: #bd2130;
            box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.25);
        }
        
        #event .input-group:focus-within .input-group-text {
            background-color: #dc3545;
            color: white;
        }
        
        #event .datetimepicker-input {
            cursor: pointer;
        }
        
        #event textarea {
            min-height: 120px;
        }
        
        #event-note-counter {
            font-weight: bold;
            color: #dc3545;
        }
		
		.input-group-text{
		padding: 0.6rem 0.75rem !important;
		}
    </style>

    <script>
        // Event functionality
        document.addEventListener('DOMContentLoaded', function() {
            // Character counter for notes
            const eventNote = document.querySelector('#event textarea[name="eventnote"]');
            const noteCounter = document.getElementById('event-note-counter');
            
            if (eventNote && noteCounter) {
                eventNote.addEventListener('input', function() {
                    const count = this.value.length;
                    noteCounter.textContent = count;
                    
                    if (count > 0) {
                        noteCounter.classList.add('animate__animated', 'animate__headShake');
                        setTimeout(() => noteCounter.classList.remove('animate__animated', 'animate__headShake'), 1000);
                    }
                    
                    if (count > 450) {
                        noteCounter.style.color = '#dc3545';
                    } else {
                        noteCounter.style.color = '#6c757d';
                    }
                });
            }
            
            // URL validation
            const eventLink = document.getElementById('eventlink');
            if (eventLink) {
                eventLink.addEventListener('blur', function() {
                    if (this.value && !this.checkValidity()) {
                        this.classList.add('animate__animated', 'animate__shakeX');
                        setTimeout(() => this.classList.remove('animate__animated', 'animate__shakeX'), 1000);
                    }
                });
            }
            
            // Datepicker initialization
            $('#eventstart, #eventend').on('change.datetimepicker', function(e) {
                $(this).addClass('animate__animated animate__pulse');
                setTimeout(() => $(this).removeClass('animate__animated animate__pulse'), 1000);
            });
            
            // Reminder select animation
            const reminderSelect = document.getElementById('eventreminder');
            if (reminderSelect) {
                reminderSelect.addEventListener('change', function() {
                    this.classList.add('animate__animated', 'animate__tada');
                    setTimeout(() => this.classList.remove('animate__animated', 'animate__tada'), 1000);
                });
            }
        });
    </script>
    <?php
}