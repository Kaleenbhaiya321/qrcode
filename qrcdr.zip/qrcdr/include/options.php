<?php
$accordion_parent = qrcdr()->getConfig('accordion') == true ? ' data-bs-parent="#collapseSettings" data-parent="#collapseSettings"' : '';
$collapsed = qrcdr()->getConfig('accordion') == true ? '' : ' show';
?>
<div class="accordion" id="collapseSettings">
<?php
if (in_array('colors', $active_options)) { ?>
    <div class="accordion-item border-0 mb-3 shadow-sm animate__animated animate__fadeIn">
        <div class="accordion-header">
            <button class="accordion-button bg-primary text-white rounded-top-3 collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseColors">
                <i class="fas fa-palette me-2"></i>
                <span class="fw-bold"><?php echo qrcdr()->getString('colors'); ?></span>
            </button>
        </div>
        <div class="accordion-collapse collapse<?php echo $collapsed; ?> rounded-bottom-3" id="collapseColors"<?php echo $accordion_parent; ?>>
            <div class="accordion-body p-0">
                <div class="p-3 custom-background">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="fw-bold text-primary">
                                    <i class="fas fa-fill-drip me-1"></i>
                                    <?php echo qrcdr()->getString('background'); ?>
                                </label>
                                <div class="input-group animate__animated animate__pulse animate__delay-1s">
                                    <span class="input-group-text bg-light">
                                        <i class="fas fa-square" style="color: <?php echo $stringbackcolor; ?>"></i>
                                    </span>
                                    <input type="text" class="form-control qrcolorpicker colorpickerback rounded-end ltr" value="<?php echo $stringbackcolor; ?>" name="backcolor">
                                </div>
                                <div class="form-check form-switch mt-2">
                                    <input type="checkbox" class="form-check-input" id="trans-bg" name="transparent">
                                    <label class="form-check-label" for="trans-bg">
                                        <i class="fas fa-eye-slash me-1"></i>
                                        <?php echo qrcdr()->getString('transparent_background'); ?>
                                    </label>
                                </div>
                                <div class="form-check form-switch mb-2">
                                    <input type="checkbox" class="form-check-input collapse-control" id="transparent-qr" data-bs-target="#collapse-image-bg" data-target="#collapse-image-bg" name="transparent_code">
                                    <label class="form-check-label" for="transparent-qr">
                                        <i class="fas fa-image me-1"></i>
                                        <?php echo qrcdr()->getString('background_image'); ?>
                                    </label>
                                </div>
                                <div class="collapse" id="collapse-image-bg">
                                    <div class="image-editor ltr">
                                        <button title="<?php echo qrcdr()->getString('background_image'); ?>" type="button" class="btn btn-primary select-image-btn rounded-0">
                                            <i class="fas fa-upload me-1"></i> <?php echo qrcdr()->getString('upload'); ?>
                                        </button>
                                        <button type="button" class="btn btn-primary export-bg-image d-none rounded-0">
                                            <i class="fas fa-check me-1"></i> <?php echo qrcdr()->getString('apply'); ?>
                                        </button>
                                        <button type="button" class="btn btn-primary remove-bg-image d-none rounded-0">
                                            <i class="fas fa-times me-1"></i> <?php echo qrcdr()->getString('remove'); ?>
                                        </button>
                                        <input type="file" class="cropit-image-input nopreview">
                                        <div class="cropit-preview mx-auto"></div>
                                        <input type="range" class="cropit-image-zoom-input qrcdr-slider-input nopreview">
                                    </div>
                                    <input id="bg_image" type="hidden" name="bg_image">
                                    <div class="form-check form-switch d-none negative-code">
                                        <input type="checkbox" class="form-check-input" id="negative-qr" name="negative_qr">
                                        <label class="form-check-label" for="negative-qr">
                                            <i class="fas fa-mask me-1"></i>
                                            <?php echo qrcdr()->getString('masked'); ?>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="fw-bold text-primary">
                                    <i class="fas fa-paint-brush me-1"></i>
                                    <?php echo qrcdr()->getString('foreground'); ?>
                                </label>
                                <div class="input-group animate__animated animate__pulse animate__delay-1s">
                                    <span class="input-group-text bg-light">
                                        <i class="fas fa-square" style="color: <?php echo $stringfrontcolor; ?>"></i>
                                    </span>
                                    <input type="text" class="form-control qrcolorpicker rounded-end ltr" value="<?php echo $stringfrontcolor; ?>" name="frontcolor">
                                </div>
                                <div class="form-group mt-3">
                                    <div class="form-check form-switch">
                                        <input type="checkbox" class="form-check-input collapse-control" id="gradient-bg" data-bs-target="#collapse-gradient" data-target="#collapse-gradient" name="gradient">
                                        <label class="form-check-label" for="gradient-bg">
                                            <i class="fas fa-gradient me-1"></i>
                                            <?php echo qrcdr()->getString('gradient'); ?>
                                        </label>
                                    </div>
                                </div>
                                <div class="collapse" id="collapse-gradient">
                                    <label class="fw-bold text-primary">
                                        <i class="fas fa-palette me-1"></i>
                                        <?php echo qrcdr()->getString('second_color'); ?>
                                    </label>
                                    <input type="text" class="form-control qrcolorpicker qrcolorpicker_bg rounded ltr" value="#8900D5" name="gradient_color">
                                    <div class="form-group mt-2">
                                        <div class="form-check form-switch">
                                            <input type="checkbox" class="form-check-input" id="radial-gradient" name="radial">
                                            <label class="form-check-label" for="radial-gradient">
                                                <i class="fas fa-circle-notch me-1"></i>
                                                <?php echo qrcdr()->getString('radial'); ?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php
}

if (in_array('design', $active_options)) { 
    require dirname(dirname(__FILE__)).'/lib/markers.php';
    $patterns = $markersIn;

    $styleselecta = '<div class="styleselecta d-flex flex-wrap gap-2">';
    foreach ($patterns as $marker => $values) {
        if (isset($values['preview'])) {
            $activeattr = ($marker == 'default') ? 'checked' : '';
            $styleselecta .= '<input type="radio" name="pattern" id="pattern_'.$marker.'" value="'.$marker.'" '.$activeattr.' class="btn-check" autocomplete="off">
            <label class="btn btn-outline-primary p-2" for="pattern_'.$marker.'">
                <svg width="38" height="38" viewBox="0 0 6 6" xmlns="http://www.w3.org/2000/svg">'.$values['preview'].'</svg>
            </label>';
        }
    }
    $styleselecta .= '</div>';

    $markerselecta = '<div class="btn-group-toggle styleselecta d-flex flex-wrap gap-2">';
    foreach ($markers as $marker => $values) {
        $activeattr = ($marker == 'default') ? 'checked' : '';
        $markerselecta .= '<input type="radio" name="marker_out" id="marker_out_'.$marker.'" value="'.$marker.'" '.$activeattr.' class="btn-check" autocomplete="off">
        <label for="marker_out_'.$marker.'" class="btn btn-outline-primary p-2">
            <svg width="32" height="32" viewBox="0 0 14 14" fill="currentColor" xmlns="http://www.w3.org/2000/svg">'.$values['path'].'</svg>
        </label>';
    }
    $markerselecta .= '</div>';

    $markerselectaIn = '<div class="btn-group-toggle styleselecta d-flex flex-wrap gap-2">';
    foreach ($markersIn as $marker => $values) {
        if (isset($values['marker']) && $values['marker'] === true) {
            $activeattr = ($marker == 'default') ? 'checked' : '';
            $markerselectaIn .= '<input type="radio" name="marker_in" id="marker_in_'.$marker.'" value="'.$marker.'" '.$activeattr.' class="btn-check" autocomplete="off">
            <label for="marker_in_'.$marker.'" class="btn btn-outline-primary p-2">
                <svg width="14" height="14" viewBox="0 0 6 6" fill="currentColor" xmlns="http://www.w3.org/2000/svg">'.$values['path'].'</svg>
            </label>';
        }
    }
    $markerselectaIn .= '</div>';
    ?>
    <div class="accordion-item border-0 mb-3 shadow-sm animate__animated animate__fadeIn">
        <div class="accordion-header">
            <button class="accordion-button bg-primary text-white rounded-top-3 collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseStyle">
                <i class="fas fa-paint-brush me-2"></i>
                <span class="fw-bold"><?php echo qrcdr()->getString('design'); ?></span>
            </button>
        </div>
        <div class="accordion-collapse collapse<?php echo $collapsed; ?> rounded-bottom-3" id="collapseStyle"<?php echo $accordion_parent; ?>>
            <div class="accordion-body">
                <div class="mb-4">
                    <label class="fw-bold text-primary mb-2">
                        <i class="fas fa-shapes me-1"></i>
                        <?php echo qrcdr()->getString('pattern'); ?>
                    </label>
                    <?php echo $styleselecta; ?>
                </div>

                <div class="mb-4">
                    <label class="fw-bold text-primary mb-2">
                        <i class="fas fa-qrcode me-1"></i>
                        <?php echo qrcdr()->getString('marker_outline'); ?>
                    </label>
                    <?php echo $markerselecta; ?>
                </div>

                <div class="mb-4">
                    <label class="fw-bold text-primary mb-2">
                        <i class="fas fa-bullseye me-1"></i>
                        <?php echo qrcdr()->getString('marker_center'); ?>
                    </label>
                    <?php echo $markerselectaIn; ?>
                </div>

                <div class="border-top pt-3">
                    <div class="form-check form-switch mb-3">
                        <input type="checkbox" class="form-check-input collapse-control" id="markers-bg" data-bs-target=".collapse-markers-bg" data-target=".collapse-markers-bg" name="markers_color">
                        <label class="form-check-label fw-bold" for="markers-bg">
                            <i class="fas fa-palette me-1"></i>
                            <?php echo qrcdr()->getString('custom_markers_colors'); ?>
                        </label>
                    </div>

                    <div class="collapse collapse-markers-bg">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="fw-bold text-primary">
                                    <i class="fas fa-square me-1"></i>
                                    <?php echo qrcdr()->getString('marker_outline'); ?>
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light">
                                        <i class="fas fa-square" style="color: <?php echo $stringfrontcolor; ?>"></i>
                                    </span>
                                    <input type="text" class="qrcolorpicker form-control" value="<?php echo $stringfrontcolor; ?>" name="marker_out_color">
                                </div>
                            </div>

                            <div class="col-md-6">
                                <label class="fw-bold text-primary">
                                    <i class="fas fa-square-full me-1"></i>
                                    <?php echo qrcdr()->getString('marker_center'); ?>
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light">
                                        <i class="fas fa-square" style="color: <?php echo $stringfrontcolor; ?>"></i>
                                    </span>
                                    <input type="text" class="qrcolorpicker form-control" value="<?php echo $stringfrontcolor; ?>" name="marker_in_color">
                                </div>
                            </div>
                        </div>

                        <div class="form-check form-switch mt-3">
                            <input type="checkbox" class="form-check-input collapse-control" id="different-markers-bg" data-bs-target="#collapse-different-markers-bg" data-target="#collapse-different-markers-bg" name="different_markers_color">
                            <label class="form-check-label fw-bold" for="different-markers-bg">
                                <i class="fas fa-star-half-alt me-1"></i>
                                <?php echo qrcdr()->getString('different_markers_colors'); ?>
                            </label>
                        </div>

                        <div class="collapse mt-3" id="collapse-different-markers-bg">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="fw-bold text-primary">
                                        <i class="fas fa-arrow-up-right me-1"></i>
                                        <?php echo qrcdr()->getString('top_right'); ?> (<?php echo qrcdr()->getString('outline'); ?>)
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light">
                                            <i class="fas fa-square" style="color: <?php echo $stringfrontcolor; ?>"></i>
                                        </span>
                                        <input type="text" class="qrcolorpicker form-control" value="<?php echo $stringfrontcolor; ?>" name="marker_top_right_outline">
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <label class="fw-bold text-primary">
                                        <i class="fas fa-arrow-up-right me-1"></i>
                                        <?php echo qrcdr()->getString('top_right'); ?> (<?php echo qrcdr()->getString('center'); ?>)
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light">
                                            <i class="fas fa-square" style="color: <?php echo $stringfrontcolor; ?>"></i>
                                        </span>
                                        <input type="text" class="qrcolorpicker form-control" value="<?php echo $stringfrontcolor; ?>" name="marker_top_right_center">
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <label class="fw-bold text-primary">
                                        <i class="fas fa-arrow-down-left me-1"></i>
                                        <?php echo qrcdr()->getString('bottom_left'); ?> (<?php echo qrcdr()->getString('outline'); ?>)
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light">
                                            <i class="fas fa-square" style="color: <?php echo $stringfrontcolor; ?>"></i>
                                        </span>
                                        <input type="text" class="qrcolorpicker form-control" value="<?php echo $stringfrontcolor; ?>" name="marker_bottom_left_outline">
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <label class="fw-bold text-primary">
                                        <i class="fas fa-arrow-down-left me-1"></i>
                                        <?php echo qrcdr()->getString('bottom_left'); ?> (<?php echo qrcdr()->getString('center'); ?>)
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light">
                                            <i class="fas fa-square" style="color: <?php echo $stringfrontcolor; ?>"></i>
                                        </span>
                                        <input type="text" class="qrcolorpicker form-control" value="<?php echo $stringfrontcolor; ?>" name="marker_bottom_left_center">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
}

/**
 * Watermarks
 */
$waterdir = $relative."images/watermarks/";
$watermarks = glob($waterdir.'*.{gif,jpg,png,svg}', GLOB_BRACE);

if (qrcdr()->getConfig('brand_logo') === true && isset($watermarks[0])) {
    $water = $watermarks[0];
    $watervalue = $watermarks[0];

    if (substr($water, 0, strlen($relative)) == $relative) {
        $watervalue = substr($water, strlen($relative));
    }
    echo '<input type="hidden" name="brand_logo" value="'.$watervalue.'">';
}

if (in_array('logo', $active_options)) { 
    $listwatermarks = '';

    foreach ($watermarks as $key => $water) {
        $altImg = str_replace(array('-', '_'), ' ', pathinfo($water, PATHINFO_FILENAME));
        $watervalue = $water;

        if (substr($water, 0, strlen($relative)) == $relative) {
            $watervalue = substr($water, strlen($relative));
        }

        $listwatermarks .= '<input id="water_'.$key.'" type="radio" name="optionlogo" value="'.$watervalue.'"';
        if ($optionlogo == $watervalue) $listwatermarks .= ' checked';
        $listwatermarks .= ' id="optionlogo'.$key.'" class="btn-check">';
        $listwatermarks .= '<label for="water_'.$key.'" class="btn btn-outline-primary p-2"><img alt="'.$altImg.'" src="'.$water.'" class="img-fluid" style="max-height: 40px;"></label>';
    }
    ?>
    <div class="accordion-item border-0 mb-3 shadow-sm animate__animated animate__fadeIn">
        <div class="accordion-header">
            <button class="accordion-button bg-primary text-white rounded-top-3 collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseWatermark">
                <i class="fas fa-image me-2"></i>
                <span class="fw-bold"><?php echo qrcdr()->getString('logo'); ?></span>
            </button>
        </div>
        <div class="accordion-collapse collapse<?php echo $collapsed; ?> rounded-bottom-3" id="collapseWatermark"<?php echo $accordion_parent; ?>>
            <div class="accordion-body">
                <?php if (qrcdr()->getConfig('uploader') == true) { ?>
                <div class="mb-3">
                    <label class="fw-bold text-primary mb-2">
                        <i class="fas fa-upload me-1"></i>
                        <?php echo qrcdr()->getString('upload_or_select_watermark'); ?>
                    </label>
                    <div class="custom-file">
                        <input type="file" name="file" class="custom-file-input form-control" aria-describedby="validate-upload" id="upmarker">
                        <div id="validate-upload" class="invalid-feedback">
                            <?php echo qrcdr()->getString('invalid_image'); ?>
                        </div>
                        <label class="custom-file-label" for="upmarker"></label>
                    </div>
                </div>
                <?php } ?>

                <?php if (qrcdr()->getConfig('uploader') == true || count($watermarks) > 0) { ?>
                <div class="mb-3">
                    <label class="fw-bold text-primary mb-2">
                        <i class="fas fa-images me-1"></i>
                        <?php echo qrcdr()->getString('select_logo'); ?>
                    </label>
                    <div class="logoselecta">
                        <div class="d-flex flex-wrap gap-2">
                            <label class="btn btn-outline-primary p-2">
                                <input type="radio" name="optionlogo" value="none" checked="" class="btn-check">
                                <i class="fas fa-times fa-lg"></i>
                            </label>
                            <?php echo $listwatermarks; ?>
                            <label class="btn btn-outline-primary p-2 custom-watermark">
                                <input type="radio" name="optionlogo" value="" class="btn-check">
                                <div class="hold-custom-watermark"></div>
                            </label>
                        </div>
                    </div>
                </div>

                <div class="form-check form-switch mb-3">
                    <input type="checkbox" class="form-check-input" id="no-logo-bg" name="no_logo_bg">
                    <label class="form-check-label" for="no-logo-bg">
                        <i class="fas fa-eye-slash me-1"></i>
                        <?php echo qrcdr()->getString('no_logo_background'); ?>
                    </label>
                </div>

                <div class="qrcdr-slider mb-3">
                    <label class="fw-bold text-primary mb-2">
                        <i class="fas fa-arrows-alt-v me-1"></i>
                        <?php echo qrcdr()->getString('logo_size'); ?>
                    </label>
                    <input type="range" min="30" max="100" value="100" class="qrcdr-slider-input" name="logo_size">
                    <div class="d-flex justify-content-between">
                        <small><?php echo qrcdr()->getString('size'); ?>:</small>
                        <small><span class="qrcdr-slider-value">100</span>%</small>
                    </div>
                </div>
                <?php } ?>
            </div>
        </div>
    </div>
    <?php
}

if (in_array('frame', $active_options)) {
    include dirname(__DIR__).'/lib/frames.php';

    $frameselecta = '<div class="d-flex flex-wrap gap-2">';
    foreach ($frames as $frame => $values) {
        $activeattr = $frame == 'none' ? 'checked' : '';
        $viewH = isset($values['label_size']) && isset($values['label_offset']) ? (24 + $values['label_size'] + 2 + $values['label_offset']) : 24;
        $frameselecta .= '<input type="radio" name="outer_frame" id="outer_frame_'.$frame.'" value="'.$frame.'" '.$activeattr.' class="btn-check" autocomplete="off">
        <label for="outer_frame_'.$frame.'" class="btn btn-outline-primary p-2">
            <svg width="48" height="56" viewBox="0 0 24 '.$viewH.'" fill="currentColor" xmlns="http://www.w3.org/2000/svg">'.$values['path'].'</svg>
        </label>';
    }
    $frameselecta .= '</div>';
    ?>
    <div class="accordion-item border-0 mb-3 shadow-sm animate__animated animate__fadeIn">
        <div class="accordion-header">
            <button class="accordion-button bg-primary text-white rounded-top-3 collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFrame">
                <i class="fas fa-border-style me-2"></i>
                <span class="fw-bold"><?php echo qrcdr()->getString('frame'); ?></span>
            </button>
        </div>
        <div class="accordion-collapse collapse<?php echo $collapsed; ?> rounded-bottom-3" id="collapseFrame"<?php echo $accordion_parent; ?>>
            <div class="accordion-body">
                <div class="mb-4">
                    <label class="fw-bold text-primary mb-2">
                        <i class="fas fa-shapes me-1"></i>
                        <?php echo qrcdr()->getString('frame_style'); ?>
                    </label>
                    <?php echo $frameselecta; ?>
                </div>

                <div class="row g-3 mb-4">
                    <div class="col-md-6">
                        <label class="fw-bold text-primary">
                            <i class="fas fa-font me-1"></i>
                            <?php echo qrcdr()->getString('frame_label'); ?>
                        </label>
                        <input class="form-control" type="text" name="framelabel" value="<?php echo qrcdr()->getString('scan_me'); ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="fw-bold text-primary">
                            <i class="fas fa-font-case me-1"></i>
                            <?php echo qrcdr()->getString('label_font'); ?>
                        </label>
                        <select name="label_font" class="form-select">
                            <?php
                            if ($rtl['dir'] == 'rtl') {
                                ?>
                            <option value="Arial, Helvetica, sans-serif">
                                Sans serif
                            </option>
                                <?php  
                            } else {
                                $fontdir = dirname(dirname(__FILE__)).'/lib/fonts';
                                $getfonts = glob($fontdir.'/*.svg');
                                foreach ($getfonts as $key => $font) {
                                    ?>
                            <option value="<?php echo basename($font); ?>">
                                    <?php echo basename($font, '.svg'); ?>
                            </option>
                                    <?php
                                }
                            } ?>
                        </select>
                    </div>
                </div>

                <div class="qrcdr-slider mb-4">
                    <label class="fw-bold text-primary mb-2">
                        <i class="fas fa-text-height me-1"></i>
                        <?php echo qrcdr()->getString('text_size'); ?>
                    </label>
                    <input type="range" min="10" max="100" value="100" class="qrcdr-slider-input" name="label-text-size">
                    <div class="d-flex justify-content-between">
                        <small><?php echo qrcdr()->getString('size'); ?>:</small>
                        <small><span class="qrcdr-slider-value">100</span>%</small>
                    </div>
                </div>

                <div class="form-check form-switch mb-3">
                    <input type="checkbox" class="form-check-input collapse-control" id="frame-color" data-bs-target="#collapse-frame-color" data-target="#collapse-frame-color" name="custom_frame_color">
                    <label class="form-check-label fw-bold" for="frame-color">
                        <i class="fas fa-palette me-1"></i>
                        <?php echo qrcdr()->getString('custom_frame_color'); ?>
                    </label>
                </div>

                <div class="collapse" id="collapse-frame-color">
                    <label class="fw-bold text-primary mb-2">
                        <i class="fas fa-fill-drip me-1"></i>
                        <?php echo qrcdr()->getString('frame_color'); ?>
                    </label>
                    <div class="input-group">
                        <span class="input-group-text bg-light">
                            <i class="fas fa-square" style="color: <?php echo $stringfrontcolor; ?>"></i>
                        </span>
                        <input type="text" class="form-control qrcolorpicker" value="<?php echo $stringfrontcolor; ?>" name="framecolor">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
}

if (in_array('options', $active_options)) { ?>
    <div class="accordion-item border-0 mb-3 shadow-sm animate__animated animate__fadeIn">
        <div class="accordion-header">
            <button class="accordion-button bg-primary text-white rounded-top-3 collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOptions">
                <i class="fas fa-cog me-2"></i>
                <span class="fw-bold"><?php echo qrcdr()->getString('options'); ?></span>
            </button>
        </div>
        <div class="accordion-collapse collapse<?php echo $collapsed; ?> rounded-bottom-3" id="collapseOptions"<?php echo $accordion_parent; ?>>
            <div class="accordion-body">
                <div class="row g-3 mb-4">
                    <div class="col-md-6">
                        <label class="fw-bold text-primary">
                            <i class="fas fa-ruler me-1"></i>
                            <?php echo qrcdr()->getString('size'); ?>
                        </label>
                        <select name="size" class="form-select qrcode-size-selector">
                            <?php
                            for ($i=8; $i<=32; $i+=4) {
                                $value = $i*25;
                                echo '<option value="'.$i.'" '.( $matrixPointSize == $i ? 'selected' : '' ) . '>'.$value.'px</option>';
                            }; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="fw-bold text-primary">
                            <i class="fas fa-shield-alt me-1"></i>
                            <?php echo qrcdr()->getString('error_correction_level'); ?>
                        </label>
                        <select name="level" class="form-select">
                            <option value="L" <?php if ($errorCorrectionLevel=="L") echo "selected"; ?>>
                                <?php echo qrcdr()->getString('precision_l'); ?>
                            </option>
                            <option value="M" <?php if ($errorCorrectionLevel=="M") echo "selected"; ?>>
                                <?php echo qrcdr()->getString('precision_m'); ?>
                            </option>
                            <option value="Q" <?php if ($errorCorrectionLevel=="Q") echo "selected"; ?>>
                                <?php echo qrcdr()->getString('precision_q'); ?>
                            </option>
                            <option value="H" <?php if ($errorCorrectionLevel=="H") echo "selected"; ?>>
                                <?php echo qrcdr()->getString('precision_h'); ?>
                            </option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
</div>

<style>
/* Custom accordion styling */
.accordion-button {
    transition: all 0.3s ease;
    padding: 1rem 1.25rem;
}

.accordion-button:not(.collapsed) {
    background-color: var(--bs-primary);
    color: white;
    box-shadow: none;
}

.accordion-button:focus {
    box-shadow: none;
    border-color: transparent;
}

.accordion-body {
    padding: 0;
}

.accordion-collapse {
    border: 1px solid rgba(0,0,0,.125);
    border-top: none;
    border-radius: 0 0 0.5rem 0.5rem;
}

/* Custom color picker styling */
.qrcolorpicker {
    cursor: pointer;
}

/* Custom slider styling */
.qrcdr-slider {
    padding: 0.5rem 0;
}

.qrcdr-slider-input {
    width: 100%;
    margin: 0.5rem 0;
}

/* Custom button styling */
.btn-check:checked + .btn-outline-primary {
    background-color: var(--bs-primary);
    color: white;
    border-color: var(--bs-primary);
}

/* Animation classes */
.animate__animated {
    animation-duration: 0.5s;
}

/* Custom input group styling */
.input-group-text {
    transition: all 0.3s ease;
}

.input-group:focus-within .input-group-text {
    background-color: var(--bs-primary);
    color: white;
}

/* Custom form switch styling */
.form-check-input:checked {
    background-color: var(--bs-primary);
    border-color: var(--bs-primary);
}
.accordion{
margin-top: 30px;
}

.accordion-header{
box-shadow: 0 4px 8px rgb(255 255 255 / 34%);
    font-weight: bold;
}
.accordion-body {
    padding: 25px;
}
.accordion-button{
background: linear-gradient(90deg, #ff8a00, #e52e71, #1a2980);
    background-size: 200% 100%;
    animation: gradientFlow 8s ease infinite;
	padding: 0.5rem 1.25rem;
}
/* Custom file input styling */
.custom-file-input ~ .custom-file-label::after {
    content: "<?php echo qrcdr()->getString('browse'); ?>";
}
</style>

<script>
// Initialize animations and interactions
document.addEventListener('DOMContentLoaded', function() {
    // Accordion toggle animation
    const accordionButtons = document.querySelectorAll('.accordion-button');
    accordionButtons.forEach(button => {
        button.addEventListener('click', function() {
            this.classList.add('animate__animated', 'animate__pulse');
            setTimeout(() => this.classList.remove('animate__animated', 'animate__pulse'), 500);
        });
    });

    // Update slider value displays
    const sliders = document.querySelectorAll('.qrcdr-slider-input');
    sliders.forEach(slider => {
        const valueDisplay = slider.closest('.qrcdr-slider').querySelector('.qrcdr-slider-value');
        if (valueDisplay) {
            valueDisplay.textContent = slider.value;
            slider.addEventListener('input', function() {
                valueDisplay.textContent = this.value;
                this.closest('.qrcdr-slider').classList.add('animate__animated', 'animate__headShake');
                setTimeout(() => this.closest('.qrcdr-slider').classList.remove('animate__animated', 'animate__headShake'), 500);
            });
        }
    });

    // Custom file input
    const fileInputs = document.querySelectorAll('.custom-file-input');
    fileInputs.forEach(input => {
        input.addEventListener('change', function() {
            const fileName = this.files[0] ? this.files[0].name : "<?php echo qrcdr()->getString('no_file_selected'); ?>";
            const label = this.nextElementSibling;
            label.textContent = fileName;
            label.classList.add('animate__animated', 'animate__rubberBand');
            setTimeout(() => label.classList.remove('animate__animated', 'animate__rubberBand'), 1000);
        });
    });

    // Color picker initialization
    if (typeof $.fn.colorpicker !== 'undefined') {
        $('.qrcolorpicker').colorpicker({
            format: 'hex',
            align: 'left',
            autoInputFallback: false
        }).on('colorpickerChange', function(event) {
            $(this).closest('.input-group').find('.fa-square').css('color', event.color.toString());
            $(this).closest('.input-group').addClass('animate__animated animate__pulse');
            setTimeout(() => $(this).closest('.input-group').removeClass('animate__animated animate__pulse'), 500);
        });
    }
});
</script>