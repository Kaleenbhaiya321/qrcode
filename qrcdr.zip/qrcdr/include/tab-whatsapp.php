<?php
/**
 * WHATSAPP - Enhanced with animations and consistent UI
 */
if (qrcdr()->getConfig('whatsapp') == true) { ?>
    <div class="tab-pane fade<?php if ($getsection === "#whatsapp") echo " show active"; ?>" id="whatsapp">
        <div class="card border-success shadow-sm animate__animated animate__fadeIn">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0">
                    <i class="fab fa-whatsapp mr-2"></i>
                    WhatsApp
                </h4>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 form-group">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-globe-americas mr-1"></i>
                            <?php echo qrcdr()->getString('country_code'); ?>
                        </label>
                        <div class="input-group animate__animated animate__pulse animate__delay-1s">
                            <div class="input-group-prepend">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-flag"></i>
                                </span>
                            </div>
                            <?php
                            $output = '<select class="form-select custom-select" name="wapp_countrycode" required="required"
                                onfocus="this.parentElement.classList.add(\'shadow\')"
                                onblur="this.parentElement.classList.remove(\'shadow\')">';
                            foreach ($countries as $i=>$row) {
                                $selected = ($row['code'] == '1') ? 'selected' : ''; // Default to US
                                $output .= '<option value="'.$row['code'].'" label="'.$row['name'].'" '.$selected.'>'.$row['name'].' (+'.$row['code'].')</option>';
                            }
                            $output .= '</select>';
                            echo $output;
                            ?> 
                        </div>
						
                    </div>

                    <div class="col-md-8 form-group">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-mobile-alt mr-1"></i>
                            <?php echo qrcdr()->getString('phone_number'); ?>
                        </label>
                        <div class="input-group animate__animated animate__pulse animate__delay-1s">
                            <div class="input-group-prepend">
                                <span class="input-group-text bg-light">
                                    <i class="fab fa-whatsapp"></i>
                                </span>
                            </div>
							
                            <input type="number" name="wapp_number" 
                                class="form-control" 
                                required="required"
                                placeholder="Enter Whatsapp Number"
                                onfocus="this.parentElement.classList.add('shadow')"
                                onblur="this.parentElement.classList.remove('shadow')"
                                oninput="validateWhatsAppNumber(this)">
                            <div class="input-group-append">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-check-circle text-primary d-none" id="wapp-valid-icon"></i>
                                </span>
                            </div>
                        </div>
                        <small class="form-text text-primary mt-1">
                            <i class="fas fa-info-circle mr-1"></i>
                            Enter Number Without Country Code
                        </small>
                    </div>

                    <div class="col-12 form-group">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-comment-dots mr-1"></i>
                            <?php echo qrcdr()->getString('message'); ?>
                        </label>
                        <textarea rows="3" name="wapp_message" 
                            class="form-control animate__animated animate__pulse animate__delay-1s"
                            maxlength="750"
                            placeholder="Type Your Mhatsapp Message"
                            onfocus="this.classList.add('shadow')"
                            onblur="this.classList.remove('shadow')"
                            oninput="updateWhatsAppCounter(this)"></textarea>
                        <div class="d-flex justify-content-between mt-2">
                            <small class="form-text text-primary">
                                <i class="fas fa-info-circle mr-1"></i>
                               Max 750 Characters
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <style>
        /* Custom styling for WhatsApp inputs */
        #whatsapp input,
        #whatsapp select,
        #whatsapp textarea {
            transition: all 0.3s ease;
            border-left: 3px solid #28a745;
        }
        
        #whatsapp input:focus,
        #whatsapp select:focus,
        #whatsapp textarea:focus {
            border-color: #218838;
            box-shadow: 0 0 0 0.2rem rgba(40, 167, 69, 0.25);
        }
        
        #whatsapp .input-group:focus-within .input-group-text {
            background-color: #28a745;
            color: white;
        }
        
        #whatsapp .character-counter .current-count {
            color: #28a745;
        }
        
        #whatsapp textarea {
            min-height: 120px;
        }
        
        .fa-whatsapp {
            color: #25D366;
        }
    </style>

    <script>
        // WhatsApp functionality
        document.addEventListener('DOMContentLoaded', function() {
            // Phone number validation
            const wappInput = document.querySelector('#whatsapp input[name="wapp_number"]');
            const wappValidIcon = document.getElementById('wapp-valid-icon');
            
            if (wappInput && wappValidIcon) {
                wappInput.addEventListener('input', function() {
                    if (this.value.length > 5) {
                        wappValidIcon.classList.remove('d-none');
                        this.classList.add('is-valid');
                        wappValidIcon.classList.add('animate__animated', 'animate__rubberBand');
                        setTimeout(() => wappValidIcon.classList.remove('animate__animated', 'animate__rubberBand'), 1000);
                    } else {
                        wappValidIcon.classList.add('d-none');
                        this.classList.remove('is-valid');
                    }
                });
            }
            
            // Character counter for WhatsApp message
            function updateWhatsAppCounter(textarea) {
                const counter = textarea.parentElement.querySelector('.current-count');
                const count = textarea.value.length;
                counter.textContent = count;
                
                if (count > 0) {
                    counter.classList.add('animate__animated', 'animate__headShake');
                    setTimeout(() => counter.classList.remove('animate__animated', 'animate__headShake'), 1000);
                }
                
                if (count > 700) {
                    counter.style.color = '#dc3545';
                } else {
                    counter.style.color = '#28a745';
                }
            }
            
            // Country code selector animation
            const wappCountrySelect = document.querySelector('#whatsapp select[name="wapp_countrycode"]');
            if (wappCountrySelect) {
                wappCountrySelect.addEventListener('change', function() {
                    this.classList.add('animate__animated', 'animate__tada');
                    setTimeout(() => this.classList.remove('animate__animated', 'animate__tada'), 1000);
                });
            }
            
            // Validate WhatsApp number format
            function validateWhatsAppNumber(input) {
                // Add any custom validation logic here
            }
        });
    </script>
    <?php
}