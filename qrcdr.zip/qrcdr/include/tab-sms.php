<?php
/**
 * SMS - Enhanced with animations and consistent UI
 */
if (qrcdr()->getConfig('sms') == true) { ?>
    <div class="tab-pane fade <?php if ($getsection === "#sms") echo "show active"; ?>" id="sms">
        <div class="card border-info shadow-sm animate__animated animate__fadeIn">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0">
                    <i class="fas fa-sms mr-2"></i>
                    <?php echo qrcdr()->getString('sms'); ?>
                </h4>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 form-group">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-globe-americas mr-1"></i>
                            <?php echo qrcdr()->getString('country_code'); ?>
                        </label>
                        <div class="input-group animate__animated animate__pulse animate__delay-1s">
                            <div class="input-group-prepend">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-flag"></i>
                                </span>
                            </div>
                            <?php
                            $output = '<select class="form-select custom-select" name="countrycodesms" 
                                onfocus="this.parentElement.classList.add(\'shadow\')"
                                onblur="this.parentElement.classList.remove(\'shadow\')">';
                            foreach ($countries as $i=>$row) {
                                $output .= '<option value="'.$row['code'].'" label="'.$row['name'].'">'.$row['name'].' (+'.$row['code'].')</option>';
                            }
                            $output .= '</select>';
                            echo $output;
                            ?> 
                        </div>
                    </div>
                    <div class="col-md-8 form-group">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-mobile-alt mr-1"></i>
                            <?php echo qrcdr()->getString('phone_number'); ?>
                        </label>
                        <div class="input-group animate__animated animate__pulse animate__delay-1s">
                            <div class="input-group-prepend">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-phone"></i>
                                </span>
                            </div>
                            <input type="number" name="sms" 
                                class="form-control" 
                                required="required"
                                placeholder="Enter Phone Pumber"
                                onfocus="this.parentElement.classList.add('shadow')"
                                onblur="this.parentElement.classList.remove('shadow')"
                                oninput="validateSmsNumber(this)">
                            <div class="input-group-append">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-check-circle text-success d-none" id="sms-valid-icon"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 form-group">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-comment-dots mr-1"></i>
                            <?php echo qrcdr()->getString('message'); ?>
                        </label>
                        <textarea rows="3" name="bodysms" 
                            class="form-control animate__animated animate__pulse animate__delay-1s"
                            maxlength="160"
                            placeholder="Ttype Your Message Here"
                            onfocus="this.classList.add('shadow')"
                            onblur="this.classList.remove('shadow')"
                            oninput="updateSmsCounter(this)"></textarea>
                        <div class="d-flex justify-content-between mt-2">
                            <small class="form-text text-primary">
                                <i class="fas fa-info-circle mr-1"></i>
                                Max 160 Characters
                            </small>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>

    <style>
        /* Custom styling for SMS inputs */
        #sms input,
        #sms select,
        #sms textarea {
            transition: all 0.3s ease;
            border-left: 3px solid #17a2b8;
        }
        
        #sms input:focus,
        #sms select:focus,
        #sms textarea:focus {
            border-color: #138496;
            box-shadow: 0 0 0 0.2rem rgba(23, 162, 184, 0.25);
        }
        
        #sms .input-group:focus-within .input-group-text {
            background-color: #17a2b8;
            color: white;
        }
        
        #sms .character-counter .current-count {
            color: #17a2b8;
        }
        
        #sms textarea {
            min-height: 120px;
        }
    </style>

    <script>
        // SMS functionality
        document.addEventListener('DOMContentLoaded', function() {
            // Phone number validation
            const smsInput = document.querySelector('#sms input[name="sms"]');
            const smsValidIcon = document.getElementById('sms-valid-icon');
            
            if (smsInput && smsValidIcon) {
                smsInput.addEventListener('input', function() {
                    if (this.value.length > 5) {
                        smsValidIcon.classList.remove('d-none');
                        this.classList.add('is-valid');
                        smsValidIcon.classList.add('animate__animated', 'animate__rubberBand');
                        setTimeout(() => smsValidIcon.classList.remove('animate__animated', 'animate__rubberBand'), 1000);
                    } else {
                        smsValidIcon.classList.add('d-none');
                        this.classList.remove('is-valid');
                    }
                });
            }
            
            // Character counter for SMS message
            function updateSmsCounter(textarea) {
                const counter = textarea.parentElement.querySelector('.current-count');
                const count = textarea.value.length;
                counter.textContent = count;
                
                if (count > 0) {
                    counter.classList.add('animate__animated', 'animate__headShake');
                    setTimeout(() => counter.classList.remove('animate__animated', 'animate__headShake'), 1000);
                }
                
                if (count > 140) {
                    counter.style.color = '#dc3545';
                } else {
                    counter.style.color = '#17a2b8';
                }
            }
            
            // Country code selector animation
            const smsCountrySelect = document.querySelector('#sms select[name="countrycodesms"]');
            if (smsCountrySelect) {
                smsCountrySelect.addEventListener('change', function() {
                    this.classList.add('animate__animated', 'animate__tada');
                    setTimeout(() => this.classList.remove('animate__animated', 'animate__tada'), 1000);
                });
            }
            
            // Validate phone number format
            function validateSmsNumber(input) {
                // Add any custom validation logic here
            }
        });
    </script>
    <?php
}