<?php
/**
 * V CARD - Enhanced with animations and consistent UI
 */
if (qrcdr()->getConfig('vcard') == true) { ?>
    <div class="tab-pane fade <?php if ($getsection === "#vcard") echo "show active"; ?>" id="vcard">
        <div class="card border-primary shadow-sm animate__animated animate__fadeIn">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0">
                    <i class="fas fa-address-card mr-2"></i>
                    <?php echo qrcdr()->getString('vcard'); ?>
                </h4>
            </div>
            <div class="card-body">
                <div class="row">
                    <!-- Version Selector -->
                    <div class="col-12 form-group">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-code-branch mr-1"></i>
                            <?php echo qrcdr()->getString('version'); ?>
                        </label>
                        <div class="input-group animate__animated animate__pulse animate__delay-1s">
                            <div class="input-group-prepend">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-file-alt"></i>
                                </span>
                            </div>
                            <select class="form-select custom-select" name="vversion"
                                onfocus="this.parentElement.classList.add('shadow')"
                                onblur="this.parentElement.classList.remove('shadow')">
                                <option value="2.1">vCard 2.1</option>
                                <option value="3.0">vCard 3.0</option>
                                <option value="4.0">vCard 4.0</option>
                            </select>
                        </div>
                    </div>

                    <!-- Name Fields -->
                    <div class="col-md-2 form-group">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-user-tag mr-1"></i>
                            <?php echo qrcdr()->getString('name_title'); ?>
                        </label>
                        <input type="text" name="vnametitle" class="form-control animate__animated animate__pulse animate__delay-1s"
                            placeholder="e.g. Mr."
                            onfocus="this.classList.add('shadow')"
                            onblur="this.classList.remove('shadow')">
                    </div>
                    <div class="col-md-5 form-group">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-user mr-1"></i>
                            <?php echo qrcdr()->getString('first_name'); ?>
                        </label>
                        <input type="text" name="vname" class="form-control animate__animated animate__pulse animate__delay-1s"
                            required="required"
                            placeholder="Enter First Name"
                            onfocus="this.classList.add('shadow')"
                            onblur="this.classList.remove('shadow')">
                    </div>
                    <div class="col-md-5 form-group">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-user mr-1"></i>
                            <?php echo qrcdr()->getString('last_name'); ?>
                        </label>
                        <input type="text" name="vlast" class="form-control animate__animated animate__pulse animate__delay-1s"
                            placeholder="Enter Last Name"
                            onfocus="this.classList.add('shadow')"
                            onblur="this.classList.remove('shadow')">

                    </div>

                    <!-- Phone Numbers -->
                    <div class="col-md-6 form-group">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-phone mr-1"></i>
                            <?php echo qrcdr()->getString('phone_home'); ?>
                        </label>
                        <div class="input-group animate__animated animate__pulse animate__delay-1s">
                            <div class="input-group-prepend">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-home"></i>
                                </span>
                            </div>
                            <select class="form-select custom-select" name="countrycodevphone"
                                onfocus="this.parentElement.classList.add('shadow')"
                                onblur="this.parentElement.classList.remove('shadow')">
                                <?php foreach ($countries as $i=>$row): ?>
                                <option value="<?php echo $row['code']; ?>" <?php echo ($row['code'] == '1') ? 'selected' : ''; ?>>
                                    <?php echo $row['name']; ?> (+<?php echo $row['code']; ?>)
                                </option>
                                <?php endforeach; ?>
                            </select>
                            <input type="number" name="vphone" class="form-control"
                                placeholder="<?php echo qrcdr()->getString('phone_number'); ?>"
                                onfocus="this.parentElement.classList.add('shadow')"
                                onblur="this.parentElement.classList.remove('shadow')">
                        </div>
                    </div>

                    <div class="col-md-6 form-group">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-mobile-alt mr-1"></i>
                            <?php echo qrcdr()->getString('phone_mobile'); ?>
                        </label>
                        <div class="input-group animate__animated animate__pulse animate__delay-1s">
                            <div class="input-group-prepend">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-mobile-alt"></i>
                                </span>
                            </div>
                            <select class="form-select custom-select" name="countrycodevmobile"
                                onfocus="this.parentElement.classList.add('shadow')"
                                onblur="this.parentElement.classList.remove('shadow')">
                                <?php foreach ($countries as $i=>$row): ?>
                                <option value="<?php echo $row['code']; ?>" <?php echo ($row['code'] == '1') ? 'selected' : ''; ?>>
                                    <?php echo $row['name']; ?> (+<?php echo $row['code']; ?>)
                                </option>
                                <?php endforeach; ?>
                            </select>
                            <input type="number" name="vmobile" class="form-control"
                                placeholder="Mobile Number"
                                onfocus="this.parentElement.classList.add('shadow')"
                                onblur="this.parentElement.classList.remove('shadow')">
                        </div>
                    </div>

                    <!-- Email & Website -->
                    <div class="col-md-6 form-group">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-envelope mr-1"></i>
                            <?php echo qrcdr()->getString('email'); ?>
                        </label>
                        <div class="input-group animate__animated animate__pulse animate__delay-1s">
                            <div class="input-group-prepend">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-at"></i>
                                </span>
                            </div>
                            <input type="email" name="vemail" class="form-control"
                                placeholder="your@email.com"
                                onfocus="this.parentElement.classList.add('shadow')"
                                onblur="this.parentElement.classList.remove('shadow')">
                        </div>
                    </div>

                    <div class="col-md-6 form-group">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-globe mr-1"></i>
                            <?php echo qrcdr()->getString('website'); ?>
                        </label>
                        <div class="input-group animate__animated animate__pulse animate__delay-1s">
                            <div class="input-group-prepend">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-link"></i>
                                </span>
                            </div>
                            <input type="url" name="vurl" class="form-control"
                                placeholder="https://"
                                onfocus="this.parentElement.classList.add('shadow')"
                                onblur="this.parentElement.classList.remove('shadow')">
                        </div>
                    </div>

                    <!-- Company & Job Title -->
                    <div class="col-md-6 form-group">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-building mr-1"></i>
                            <?php echo qrcdr()->getString('company'); ?>
                        </label>
                        <input type="text" name="vcompany" class="form-control animate__animated animate__pulse animate__delay-1s"
                            placeholder="Company Name"
                            onfocus="this.classList.add('shadow')"
                            onblur="this.classList.remove('shadow')">
                    </div>

                    <div class="col-md-6 form-group">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-briefcase mr-1"></i>
                            Jobtitle
                        </label>
                        <input type="text" name="vtitle" class="form-control animate__animated animate__pulse animate__delay-1s"
                            placeholder="Your Position"
                            onfocus="this.classList.add('shadow')"
                            onblur="this.classList.remove('shadow')">
                    </div>

                    <!-- Office Phone & Fax -->
                    <div class="col-md-6 form-group">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-phone-office mr-1"></i>
                            Phone Office
                        </label>
                        <div class="input-group animate__animated animate__pulse animate__delay-1s">
                            <div class="input-group-prepend">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-building"></i>
                                </span>
                            </div>
                            <select class="form-select custom-select" name="countrycodevoffice"
                                onfocus="this.parentElement.classList.add('shadow')"
                                onblur="this.parentElement.classList.remove('shadow')">
                                <?php foreach ($countries as $i=>$row): ?>
                                <option value="<?php echo $row['code']; ?>" <?php echo ($row['code'] == '1') ? 'selected' : ''; ?>>
                                    <?php echo $row['name']; ?> (+<?php echo $row['code']; ?>)
                                </option>
                                <?php endforeach; ?>
                            </select>
                            <input type="number" name="vofficephone" class="form-control"
                                placeholder="Office Number"
                                onfocus="this.parentElement.classList.add('shadow')"
                                onblur="this.parentElement.classList.remove('shadow')">
                        </div>
                    </div>

                    <div class="col-md-6 form-group">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-fax mr-1"></i>
                            <?php echo qrcdr()->getString('fax'); ?>
                        </label>
                        <div class="input-group animate__animated animate__pulse animate__delay-1s">
                            <div class="input-group-prepend">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-fax"></i>
                                </span>
                            </div>
                            <select class="form-select custom-select" name="countrycodevfax"
                                onfocus="this.parentElement.classList.add('shadow')"
                                onblur="this.parentElement.classList.remove('shadow')">
                                <?php foreach ($countries as $i=>$row): ?>
                                <option value="<?php echo $row['code']; ?>" <?php echo ($row['code'] == '1') ? 'selected' : ''; ?>>
                                    <?php echo $row['name']; ?> (+<?php echo $row['code']; ?>)
                                </option>
                                <?php endforeach; ?>
                            </select>
                            <input type="number" name="vfax" class="form-control"
                                placeholder="Fax Number"
                                onfocus="this.parentElement.classList.add('shadow')"
                                onblur="this.parentElement.classList.remove('shadow')">
                        </div>
                    </div>

                    <!-- Address -->
                    <div class="col-12 form-group">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-map-marker-alt mr-1"></i>
                            <?php echo qrcdr()->getString('address'); ?>
                        </label>
                        <textarea name="vaddress" class="form-control animate__animated animate__pulse animate__delay-1s"
                            maxlength="255"
                            placeholder="Street Address"
                            onfocus="this.classList.add('shadow')"
                            onblur="this.classList.remove('shadow')"></textarea>
                    </div>

                    <!-- Location Details -->
                    <div class="col-md-6 form-group">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-mail-bulk mr-1"></i>
                            <?php echo qrcdr()->getString('post_code'); ?>
                        </label>
                        <input type="text" name="vcap" class="form-control animate__animated animate__pulse animate__delay-1s"

                            placeholder="Zip Code"
                            onfocus="this.classList.add('shadow')"
                            onblur="this.classList.remove('shadow')">
                    </div>
                    <div class="col-md-6 form-group">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-city mr-1"></i>
                            <?php echo qrcdr()->getString('city'); ?>
                        </label>
                        <input type="text" name="vcity" class="form-control animate__animated animate__pulse animate__delay-1s"
                            placeholder="City Name"
                            onfocus="this.classList.add('shadow')"
                            onblur="this.classList.remove('shadow')">
                    </div>
                    <div class="col-md-6 form-group">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-landmark mr-1"></i>
                            <?php echo qrcdr()->getString('state'); ?>
                        </label>
                        <input type="text" name="vstate" class="form-control animate__animated animate__pulse animate__delay-1s"
                            placeholder="State Province"
                            onfocus="this.classList.add('shadow')"
                            onblur="this.classList.remove('shadow')">
                    </div>
                    <div class="col-md-6 form-group">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-flag mr-1"></i>
                            <?php echo qrcdr()->getString('country'); ?>
                        </label>
                        <input type="text" name="vcountry" class="form-control animate__animated animate__pulse animate__delay-1s"
                            placeholder="Country Name"
                            onfocus="this.classList.add('shadow')"
                            onblur="this.classList.remove('shadow')">
                    </div>
                </div>
            </div>
            
        </div>
    </div>

    <style>
        /* Custom styling for vCard inputs */
        #vcard input,
        #vcard select,
        #vcard textarea {
            transition: all 0.3s ease;
            border-left: 3px solid #007bff;
        }
        
        #vcard input:focus,
        #vcard select:focus,
        #vcard textarea:focus {
            border-color: #0062cc;
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
        }
        
        #vcard .input-group:focus-within .input-group-text {
            background-color: #007bff;
            color: white;
        }
        
        #vcard .form-select {
            cursor: pointer;
        }
        
        #vcard .input-group-text {
            min-width: 45px;
            justify-content: center;
        }
    </style>

    <script>
        // vCard functionality
        document.addEventListener('DOMContentLoaded', function() {
            // Animate version selector on change
            const versionSelect = document.querySelector('#vcard select[name="vversion"]');
            if (versionSelect) {
                versionSelect.addEventListener('change', function() {
                    this.classList.add('animate__animated', 'animate__tada');
                    setTimeout(() => this.classList.remove('animate__animated', 'animate__tada'), 1000);
                });
            }
            
            // Validate required fields
            const requiredFields = document.querySelectorAll('#vcard input[required]');
            requiredFields.forEach(field => {
                field.addEventListener('input', function() {
                    if (this.value.length > 0) {
                        this.classList.add('is-valid');
                    } else {
                        this.classList.remove('is-valid');
                    }
                });
            });
            
            // Auto-format phone numbers
            const phoneInputs = document.querySelectorAll('#vcard input[type="number"]');
            phoneInputs.forEach(input => {
                input.addEventListener('input', function() {
                    if (this.value.length > 0) {
                        this.classList.add('is-valid');
                    } else {
                        this.classList.remove('is-valid');
                    }
                });
            });
            
            // Email validation
            const emailInput = document.querySelector('#vcard input[type="email"]');
            if (emailInput) {
                emailInput.addEventListener('blur', function() {
                    if (this.value && !this.checkValidity()) {
                        this.classList.add('animate__animated', 'animate__shakeX');
                        setTimeout(() => this.classList.remove('animate__animated', 'animate__shakeX'), 1000);
                    }
                });
            }
        });
    </script>
    <?php
}