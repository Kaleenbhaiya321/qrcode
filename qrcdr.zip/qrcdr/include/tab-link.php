<?php
/**
 * LINK - Enhanced with animations and better UI
 */
if (qrcdr()->getConfig('link') == true) { ?>
<div class="tab-pane fade <?php if ($getsection === "#link") echo "show active"; ?>" id="link">
    <div class="card border-primary shadow-sm animate__animated animate__fadeIn">
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0">
                <i class="fas fa-link mr-2"></i>
                <?php echo qrcdr()->getString('link'); ?>
            </h4>
        </div>
        <div class="card-body">
            <div class="form-group">
                <label for="malink" class="font-weight-bold text-primary">
                    <i class="fas fa-globe mr-1"></i> Website URL
                </label>
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text bg-light">
                            <i class="fas fa-external-link-alt"></i>
                        </span>
                    </div>
                    <input type="text" name="link" id="malink" 
                           class="form-control ltr animate__animated animate__pulse animate__delay-1s" 
                           placeholder="https://www.example.com" 
                           required="required" 
                           value="" 
                           onfocus="this.classList.add('shadow')"
                           onblur="this.classList.remove('shadow')"/>
                </div>
                <small class="form-text text-primary mt-2">
                    <i class="fas fa-info-circle mr-1"></i> Enter the full website address including http:// or https://
                </small>
            </div>
        </div>
    </div>
</div>
    <?php
}
?>


