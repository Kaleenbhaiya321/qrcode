<?php
/**
 * ZOOM - Enhanced with animations and consistent UI
 */
if (qrcdr()->getConfig('zoom') == true) { ?>
<div class="tab-pane fade <?php if ($getsection === "#zoom") echo "show active"; ?>" id="zoom">
    <div class="card border-info shadow-sm animate__animated animate__fadeIn">
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0">
                <i class="fas fa-video mr-2"></i>
                Zoom Meeting
            </h4>
        </div>
        <div class="card-body">
            <div class="row form-group">
                <div class="col-md-6">
                    <label class="font-weight-bold text-primary" for="zoom_id">
                        <i class="fas fa-id-card mr-1"></i>
                        <?php echo qrcdr()->getString('reunion_id'); ?>
                    </label>
                    <div class="input-group animate__animated animate__pulse animate__delay-1s">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-light">
                                <i class="fas fa-hashtag"></i>
                            </span>
                        </div>
                        <input type="text" name="zoom_id" id="zoom_id" 
                            class="form-control" 
                            required="required"
                            placeholder="Enter Meeting ID"
                            onfocus="this.parentElement.classList.add('shadow')"
                            onblur="this.parentElement.classList.remove('shadow')" />
                        <div class="input-group-append">
                            <span class="input-group-text bg-light">
                                <i class="fas fa-check-circle text-success d-none" id="zoom-id-valid-icon"></i>
                            </span>
                        </div>
                    </div>
                    <small class="form-text text-primary mt-1">
                        <i class="fas fa-info-circle mr-1"></i>
                        Example Meeting ID : 123 456 7890
                    </small>
                </div>
                
                <div class="col-md-6">
                    <label class="font-weight-bold text-primary" for="zoom_pwd">
                        <i class="fas fa-key mr-1"></i>
                        <?php echo qrcdr()->getString('password'); ?>
                    </label>
                    <div class="input-group animate__animated animate__pulse animate__delay-1s">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-light">
                                <i class="fas fa-lock"></i>
                            </span>
                        </div>
                        <input type="text" name="zoom_pwd" id="zoom_pwd" 
                            class="form-control" 
                            required="required"
                            placeholder="Enter Meeting Password"
                            onfocus="this.parentElement.classList.add('shadow')"
                            onblur="this.parentElement.classList.remove('shadow')" />
                        <div class="input-group-append">
                            <button class="btn btn-outline-secondary" type="button" id="toggleZoomPwd">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                    </div>
                    <small class="form-text text-primary mt-1">
                        <i class="fas fa-info-circle mr-1"></i>
                        Case Sensitive Password
                    </small>
                </div>
            </div>
            
            <div class="form-group mt-3">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="zoom_dialin" name="zoom_dialin">
                    <label class="form-check-label text-primary" for="zoom_dialin">
                        <i class="fas fa-phone mr-1"></i>
                        Iinclude Dial In Numbers
                    </label>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    /* Custom styling for Zoom inputs */
    #zoom input {
        transition: all 0.3s ease;
        border-left: 3px solid #17a2b8;
    }
    
    #zoom input:focus {
        border-color: #138496;
        box-shadow: 0 0 0 0.2rem rgba(23, 162, 184, 0.25);
    }
    
    #zoom .input-group:focus-within .input-group-text {
        background-color: #17a2b8;
        color: white;
    }
    
    #zoom .form-check-input:checked {
        background-color: #17a2b8;
        border-color: #17a2b8;
    }
    
    #zoom .btn-outline-secondary:hover {
        color: #fff;
        background-color: #17a2b8;
        border-color: #17a2b8;
    }
</style>

<script>
    // Zoom functionality
    document.addEventListener('DOMContentLoaded', function() {
        // Meeting ID validation
        const zoomIdInput = document.getElementById('zoom_id');
        const zoomIdValidIcon = document.getElementById('zoom-id-valid-icon');
        
        if (zoomIdInput && zoomIdValidIcon) {
            zoomIdInput.addEventListener('input', function() {
                if (this.value.length > 5) {
                    zoomIdValidIcon.classList.remove('d-none');
                    this.classList.add('is-valid');
                    zoomIdValidIcon.classList.add('animate__animated', 'animate__rubberBand');
                    setTimeout(() => zoomIdValidIcon.classList.remove('animate__animated', 'animate__rubberBand'), 1000);
                } else {
                    zoomIdValidIcon.classList.add('d-none');
                    this.classList.remove('is-valid');
                }
            });
        }
        
        // Toggle password visibility
        const togglePwdBtn = document.getElementById('toggleZoomPwd');
        const zoomPwdInput = document.getElementById('zoom_pwd');
        
        if (togglePwdBtn && zoomPwdInput) {
            togglePwdBtn.addEventListener('click', function() {
                const icon = this.querySelector('i');
                if (zoomPwdInput.type === 'password') {
                    zoomPwdInput.type = 'text';
                    icon.classList.remove('fa-eye');
                    icon.classList.add('fa-eye-slash');
                    this.classList.add('animate__animated', 'animate__flipInY');
                    setTimeout(() => this.classList.remove('animate__animated', 'animate__flipInY'), 1000);
                } else {
                    zoomPwdInput.type = 'password';
                    icon.classList.remove('fa-eye-slash');
                    icon.classList.add('fa-eye');
                }
            });
        }
        
        // Animate checkbox when checked
        const zoomDialIn = document.getElementById('zoom_dialin');
        if (zoomDialIn) {
            zoomDialIn.addEventListener('change', function() {
                this.parentElement.classList.add('animate__animated', 'animate__rubberBand');
                setTimeout(() => this.parentElement.classList.remove('animate__animated', 'animate__rubberBand'), 1000);
            });
        }
    });
</script>
<?php
}