<?php
/**
 * WI FI - Enhanced with animations and consistent UI
 */
if (qrcdr()->getConfig('wifi') == true) { ?>
    <div class="tab-pane fade <?php if ($getsection === "#wifi") echo "show active"; ?>" id="wifi">
        <div class="card border-warning shadow-sm animate__animated animate__fadeIn">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0">
                    <i class="fas fa-wifi mr-2"></i>
                    <?php echo qrcdr()->getString('wifi'); ?>
                </h4>
            </div>
            <div class="card-body">
                <div class="row form-group">
                    <div class="col-md-4">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-network-wired mr-1"></i>
                            <?php echo qrcdr()->getString('network_name'); ?>
                        </label>
                        <div class="input-group animate__animated animate__pulse animate__delay-1s">
                            <div class="input-group-prepend">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-signal"></i>
                                </span>
                            </div>
                            <input type="text" name="ssid" 
                                class="form-control" 
                                required="required"
                                placeholder="MyWiFiNetwork"
                                onfocus="this.parentElement.classList.add('shadow')"
                                onblur="this.parentElement.classList.remove('shadow')">
                            <div class="input-group-append">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-check-circle text-success d-none" id="ssid-valid-icon"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-lock mr-1"></i>
                            <?php echo qrcdr()->getString('network_type'); ?>
                        </label>
                        <div class="input-group animate__animated animate__pulse animate__delay-1s">
                            <div class="input-group-prepend">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-shield-alt"></i>
                                </span>
                            </div>
                            <select class="form-select custom-select" name="networktype"
                                onfocus="this.parentElement.classList.add('shadow')"
                                onblur="this.parentElement.classList.remove('shadow')">
                                <option value="WEP">WEP</option>
                                <option value="WPA" selected>WPA/WPA2</option>
                                <option value=""><?php echo qrcdr()->getString('no_encryption'); ?></option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label class="font-weight-bold text-primary">
                            <i class="fas fa-key mr-1"></i>
                            <?php echo qrcdr()->getString('password'); ?>
                        </label>
                        <div class="input-group animate__animated animate__pulse animate__delay-1s">
                            <div class="input-group-prepend">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-unlock-alt"></i>
                                </span>
                            </div>
                            <input type="password" name="wifipass" 
                                class="form-control"
                                placeholder="Enter Password"
                                onfocus="this.parentElement.classList.add('shadow')"
                                onblur="this.parentElement.classList.remove('shadow')">
                            <div class="input-group-append">
                                <button class="btn btn-outline-secondary" type="button" id="toggleWifiPass">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row form-group mt-3">
                    <div class="col-12">
                        <div class="form-check animate__animated animate__pulse animate__delay-1s">
                            <input type="checkbox" class="form-check-input" id="wifihidden" name="wifihidden"
                                onchange="this.parentElement.classList.toggle('text-primary')">
                            <label class="form-check-label text-primary" for="wifihidden">
                                <i class="fas fa-eye-slash mr-1"></i>
                                <?php echo qrcdr()->getString('hidden'); ?>
                            </label>
                        </div>
                        <small class="form-text text-primary">
                            <i class="fas fa-info-circle mr-1"></i>
                            Hidden Network Description
                        </small>
                    </div>
                </div>
            </div>
            
        </div>
    </div>

    <style>
        /* Custom styling for WiFi inputs */
        #wifi input,
        #wifi select {
            transition: all 0.3s ease;
            border-left: 3px solid #ffc107;
        }
        
        #wifi input:focus,
        #wifi select:focus {
            border-color: #e0a800;
            box-shadow: 0 0 0 0.2rem rgba(255, 193, 7, 0.25);
        }
        
        #wifi .input-group:focus-within .input-group-text {
            background-color: #ffc107;
            color: #212529;
        }
        
        #wifi .form-check-input:checked {
            background-color: #ffc107;
            border-color: #ffc107;
        }
        
        #wifi .btn-outline-secondary:hover {
            color: #fff;
            background-color: #ffc107;
            border-color: #ffc107;
        }
        
        #wifi .form-check-label {
            cursor: pointer;
            transition: color 0.3s;
        }
    </style>

    <script>
        // WiFi functionality
        document.addEventListener('DOMContentLoaded', function() {
            // SSID validation
            const ssidInput = document.querySelector('#wifi input[name="ssid"]');
            const ssidValidIcon = document.getElementById('ssid-valid-icon');
            
            if (ssidInput && ssidValidIcon) {
                ssidInput.addEventListener('input', function() {
                    if (this.value.length > 0) {
                        ssidValidIcon.classList.remove('d-none');
                        this.classList.add('is-valid');
                        ssidValidIcon.classList.add('animate__animated', 'animate__rubberBand');
                        setTimeout(() => ssidValidIcon.classList.remove('animate__animated', 'animate__rubberBand'), 1000);
                    } else {
                        ssidValidIcon.classList.add('d-none');
                        this.classList.remove('is-valid');
                    }
                });
            }
            
            // Toggle password visibility
            const toggleWifiPass = document.getElementById('toggleWifiPass');
            const wifiPassInput = document.querySelector('#wifi input[name="wifipass"]');
            
            if (toggleWifiPass && wifiPassInput) {
                toggleWifiPass.addEventListener('click', function() {
                    const icon = this.querySelector('i');
                    if (wifiPassInput.type === 'password') {
                        wifiPassInput.type = 'text';
                        icon.classList.remove('fa-eye');
                        icon.classList.add('fa-eye-slash');
                        this.classList.add('animate__animated', 'animate__flipInY');
                        setTimeout(() => this.classList.remove('animate__animated', 'animate__flipInY'), 1000);
                    } else {
                        wifiPassInput.type = 'password';
                        icon.classList.remove('fa-eye-slash');
                        icon.classList.add('fa-eye');
                    }
                });
            }
            
            // Animate network type on change
            const networkTypeSelect = document.querySelector('#wifi select[name="networktype"]');
            if (networkTypeSelect) {
                networkTypeSelect.addEventListener('change', function() {
                    this.classList.add('animate__animated', 'animate__tada');
                    setTimeout(() => this.classList.remove('animate__animated', 'animate__tada'), 1000);
                    
                    // Show/hide password field based on selection
                    const passwordField = document.querySelector('#wifi input[name="wifipass"]');
                    if (this.value === '') {
                        passwordField.disabled = true;
                        passwordField.placeholder = "<?php echo qrcdr()->getString('not_required'); ?>";
                    } else {
                        passwordField.disabled = false;
                        passwordField.placeholder = "<?php echo qrcdr()->getString('enter_password'); ?>";
                    }
                });
            }
            
            // Animate hidden checkbox when checked
            const wifiHidden = document.getElementById('wifihidden');
            if (wifiHidden) {
                wifiHidden.addEventListener('change', function() {
                    this.parentElement.classList.add('animate__animated', 'animate__rubberBand');
                    setTimeout(() => this.parentElement.classList.remove('animate__animated', 'animate__rubberBand'), 1000);
                });
            }
        });
    </script>
    <?php
}