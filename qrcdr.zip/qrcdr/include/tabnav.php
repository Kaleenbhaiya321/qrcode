<?php
$alignnavitems = '';
$navAnimation = 'animated fadeIn'; // Animation class
if ('vertical' == qrcdr()->getConfig('layout')) {
    $navorder = 'left' == qrcdr()->getConfig('sidebar') ? ' order-last' : '';
    $alignnavitems = ' text-sm-left text-sm-start';
    ?>
<div class="col-sm-4 col-md-3<?php echo $navorder; ?>">
<ul class="nav nav-pills flex-sm-column nav-fill sticky-top nav-zoom" role="tablist">
    <?php
} else {
    ?>
<div class="col-12">
<ul class="nav nav-pills nav-fill nav-zoom" role="tablist">
    <?php
}

// Add animation delay increment
$animationDelay = 0;

if (qrcdr()->getConfig('link') == true) { ?>
    <li class="nav-item<?php echo $alignnavitems; ?>" style="animation-delay: <?php echo $animationDelay; ?>ms">
        <a class="nav-link new<?php if ($getsection == "#link") echo " active"; ?><?php echo $rounded_btn_nav; ?> <?php echo $navAnimation; ?>" href="#link" role="tab" data-bs-toggle="tab">
            <i class="fa fa-link fa-fw"></i> 
            <span class="d-inline-block d-sm-inline-block nav-text"><?php echo qrcdr()->getString('link'); ?></span>
            <span class="nav-hover-effect"></span>
        </a>
    </li>
    <?php $animationDelay += 50; }
if (qrcdr()->getConfig('text') == true) { ?>
    <li class="nav-item<?php echo $alignnavitems; ?>" style="animation-delay: <?php echo $animationDelay; ?>ms">
        <a class="nav-link new<?php if ($getsection == "#text") echo " active"; ?><?php echo $rounded_btn_nav; ?> <?php echo $navAnimation; ?>" href="#text" role="tab" data-bs-toggle="tab">
            <i class="fa fa-align-left fa-fw"></i> 
            <span class="d-inline-block d-sm-inline-block nav-text"><?php echo qrcdr()->getString('text'); ?></span>
            <span class="nav-hover-effect"></span>
        </a>
    </li>
    <?php $animationDelay += 50; }
if (qrcdr()->getConfig('email') == true) { ?>
    <li class="nav-item<?php echo $alignnavitems; ?>" style="animation-delay: <?php echo $animationDelay; ?>ms">
        <a class="nav-link new<?php if ($getsection == "#email") echo " active"; ?><?php echo $rounded_btn_nav; ?> <?php echo $navAnimation; ?>" href="#email" role="tab" data-bs-toggle="tab">
            <i class="fa fa-envelope-o fa-fw"></i> 
            <span class="d-inline-block d-sm-inline-block nav-text"><?php echo qrcdr()->getString('email'); ?></span>
            <span class="nav-hover-effect"></span>
        </a>
    </li>
    <?php $animationDelay += 50; }
if (qrcdr()->getConfig('location') == true) { ?>
    <li class="nav-item<?php echo $alignnavitems; ?>" style="animation-delay: <?php echo $animationDelay; ?>ms">
        <a class="nav-link new<?php if ($getsection == "#location") echo " active"; ?><?php echo $rounded_btn_nav; ?> <?php echo $navAnimation; ?>" href="#location" role="tab" data-bs-toggle="tab">
            <i class="fa fa-map-marker fa-fw"></i> 
            <span class="d-inline-block d-sm-inline-block nav-text"><?php echo qrcdr()->getString('location'); ?></span>
            <span class="nav-hover-effect"></span>
        </a>
    </li>
    <?php $animationDelay += 50; }
if (qrcdr()->getConfig('tel') == true) { ?>
    <li class="nav-item<?php echo $alignnavitems; ?>" style="animation-delay: <?php echo $animationDelay; ?>ms">
        <a class="nav-link new<?php if ($getsection == "#tel") echo " active"; ?><?php echo $rounded_btn_nav; ?> <?php echo $navAnimation; ?>" href="#tel" role="tab" data-bs-toggle="tab">
            <i class="fa fa-phone fa-fw"></i> 
            <span class="d-inline-block d-sm-inline-block nav-text"><?php echo qrcdr()->getString('phone'); ?></span>
            <span class="nav-hover-effect"></span>
        </a>
    </li>
    <?php $animationDelay += 50; }
if (qrcdr()->getConfig('sms') == true) { ?>
    <li class="nav-item<?php echo $alignnavitems; ?>" style="animation-delay: <?php echo $animationDelay; ?>ms">
        <a class="nav-link new<?php if ($getsection == "#sms") echo " active"; ?><?php echo $rounded_btn_nav; ?> <?php echo $navAnimation; ?>" href="#sms" role="tab" data-bs-toggle="tab">
            <i class="fa fa-mobile fa-fw"></i> 
            <span class="d-inline-block d-sm-inline-block nav-text"><?php echo qrcdr()->getString('sms'); ?></span>
            <span class="nav-hover-effect"></span>
        </a>
    </li>
    <?php $animationDelay += 50; }
if (qrcdr()->getConfig('whatsapp') == true) { ?>
    <li class="nav-item<?php echo $alignnavitems; ?>" style="animation-delay: <?php echo $animationDelay; ?>ms">
        <a class="nav-link new<?php if ($getsection == "#whatsapp") echo " active"; ?><?php echo $rounded_btn_nav; ?> <?php echo $navAnimation; ?>" href="#whatsapp" role="tab" data-bs-toggle="tab">
            <i class="fa fa-whatsapp fa-fw"></i> 
            <span class="d-inline-block d-sm-inline-block nav-text">WhatsApp</span>
            <span class="nav-hover-effect"></span>
        </a>
    </li>
    <?php $animationDelay += 50; }
if (qrcdr()->getConfig('skype') == true) { ?>
    <li class="nav-item<?php echo $alignnavitems; ?>" style="animation-delay: <?php echo $animationDelay; ?>ms">
        <a class="nav-link new<?php if ($getsection == "#skype") echo " active"; ?><?php echo $rounded_btn_nav; ?> <?php echo $navAnimation; ?>" href="#skype" role="tab" data-bs-toggle="tab">
            <i class="fa fa-skype fa-fw"></i> 
            <span class="d-inline-block d-sm-inline-block nav-text">Skype</span>
            <span class="nav-hover-effect"></span>
        </a>
    </li>
    <?php $animationDelay += 50; }
if (qrcdr()->getConfig('zoom') == true) { ?>
    <li class="nav-item<?php echo $alignnavitems; ?>" style="animation-delay: <?php echo $animationDelay; ?>ms">
        <a class="nav-link new<?php if ($getsection == "#zoom") echo " active"; ?><?php echo $rounded_btn_nav; ?> <?php echo $navAnimation; ?>" href="#zoom" role="tab" data-bs-toggle="tab">
            <i class="fa fa-video-camera fa-fw"></i> 
            <span class="d-inline-block d-sm-inline-block nav-text">Zoom</span>
            <span class="nav-hover-effect"></span>
        </a>
    </li>
    <?php $animationDelay += 50; }
if (qrcdr()->getConfig('wifi') == true) { ?>
    <li class="nav-item<?php echo $alignnavitems; ?>" style="animation-delay: <?php echo $animationDelay; ?>ms">
        <a class="nav-link new<?php if ($getsection == "#wifi") echo " active"; ?><?php echo $rounded_btn_nav; ?> <?php echo $navAnimation; ?>" href="#wifi" role="tab" data-bs-toggle="tab">
            <i class="fa fa-wifi fa-fw"></i> 
            <span class="d-inline-block d-sm-inline-block nav-text"><?php echo qrcdr()->getString('wifi'); ?></span>
            <span class="nav-hover-effect"></span>
        </a>
    </li>
    <?php $animationDelay += 50; }
if (qrcdr()->getConfig('vcard') == true) { ?>
    <li class="nav-item<?php echo $alignnavitems; ?>" style="animation-delay: <?php echo $animationDelay; ?>ms">
        <a class="nav-link new<?php if ($getsection == "#vcard") echo " active"; ?><?php echo $rounded_btn_nav; ?> <?php echo $navAnimation; ?>" href="#vcard" role="tab" data-bs-toggle="tab">
            <i class="fa fa-list-alt fa-fw"></i> 
            <span class="d-inline-block d-sm-inline-block nav-text"><?php echo qrcdr()->getString('vcard'); ?></span>
            <span class="nav-hover-effect"></span>
        </a>
    </li>
    <?php $animationDelay += 50; }
if (qrcdr()->getConfig('event') == true) { ?>
    <li class="nav-item<?php echo $alignnavitems; ?>" style="animation-delay: <?php echo $animationDelay; ?>ms">
        <a class="nav-link new<?php if ($getsection == "#event") echo " active"; ?><?php echo $rounded_btn_nav; ?> <?php echo $navAnimation; ?>" href="#event" role="tab" data-bs-toggle="tab">
            <i class="fa fa-calendar-o fa-fw"></i> 
            <span class="d-inline-block d-sm-inline-block nav-text"><?php echo qrcdr()->getString('event'); ?></span>
            <span class="nav-hover-effect"></span>
        </a>
    </li>
    <?php $animationDelay += 50; }
if (qrcdr()->getConfig('paypal') == true) { ?>
    <li class="nav-item<?php echo $alignnavitems; ?>" style="animation-delay: <?php echo $animationDelay; ?>ms">
        <a class="nav-link new<?php if ($getsection == "#paypal") echo " active"; ?><?php echo $rounded_btn_nav; ?> <?php echo $navAnimation; ?>" href="#paypal" role="tab" data-bs-toggle="tab">
            <i class="fa fa-paypal fa-fw"></i> 
            <span class="d-inline-block d-sm-inline-block nav-text"><?php echo qrcdr()->getString('paypal'); ?></span>
            <span class="nav-hover-effect"></span>
        </a>
    </li>
    <?php $animationDelay += 50; }
if (qrcdr()->getConfig('bitcoin') == true) { ?>
    <li class="nav-item<?php echo $alignnavitems; ?>" style="animation-delay: <?php echo $animationDelay; ?>ms">
        <a class="nav-link new<?php if ($getsection == "#bitcoin") echo " active"; ?><?php echo $rounded_btn_nav; ?> <?php echo $navAnimation; ?>" href="#bitcoin" role="tab" data-bs-toggle="tab">
            <i class="fa fa-bitcoin fa-fw"></i> 
            <span class="d-inline-block d-sm-inline-block nav-text"><?php echo qrcdr()->getString('bitcoin'); ?></span>
            <span class="nav-hover-effect"></span>
        </a>
    </li>
    <?php $animationDelay += 50; } ?>
</ul>
</div>
<style>
.nav-pills .new.active, .nav-pills .show>.nav-link {
    color: var(--bs-nav-pills-link-active-color) !important;
    background: linear-gradient(90deg, #ff8a00, #e52e71, #1a2980) !important;
    background-size: 200% 100% !important;
    animation: gradientFlow 8s ease infinite !important;
}
.bg-primary{

    background: linear-gradient(90deg, #ff8a00, #e52e71, #1a2980) !important;
    background-size: 200% 100% !important;
    animation: gradientFlow 8s ease infinite !important;
}
.qrsection{
box-shadow: 0 4px 20px rgb(255 255 255);
}
</style>
<?php
$verticol = ('vertical' == qrcdr()->getConfig('layout')) ? 'col-sm-8 col-md-9' : 'col-12';
?>
<div class="<?php echo $verticol; ?>">

