<?php
/**
 * TEL - Enhanced with animations and consistent UI
 */
if (qrcdr()->getConfig('tel') == true) { ?>
    <div class="tab-pane fade <?php if ($getsection === "#tel") echo "show active"; ?>" id="tel">
        <div class="card border-warning shadow-sm animate__animated animate__fadeIn">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0">
                    <i class="fas fa-phone-alt mr-2"></i>
                    <?php echo qrcdr()->getString('tel'); ?>
                </h4>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="font-weight-bold text-primary">
                                <i class="fas fa-globe-americas mr-1"></i>
                                <?php echo qrcdr()->getString('country_code'); ?>
                            </label>
                            <div class="input-group animate__animated animate__pulse animate__delay-1s">
                                <div class="input-group-prepend">
                                    <span class="input-group-text bg-light">
                                        <i class="fas fa-flag"></i>
                                    </span>
                                </div>
                                <?php
                                $output = '<select class="form-select custom-select" name="countrycodetel" 
                                    onfocus="this.parentElement.classList.add(\'shadow\')"
                                    onblur="this.parentElement.classList.remove(\'shadow\')">';
                                foreach ($countries as $i=>$row) {
                                    $output .= '<option value="'.$row['code'].'" label="'.$row['name'].'">'.$row['name'].' (+'.$row['code'].')</option>';
                                }
                                $output .= '</select>';
                                echo $output;
                                ?> 
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="form-group">
                            <label class="font-weight-bold text-primary">
                                <i class="fas fa-mobile-alt mr-1"></i>
                                <?php echo qrcdr()->getString('phone_number'); ?>
                            </label>
                            <div class="input-group animate__animated animate__pulse animate__delay-1s">
                                <div class="input-group-prepend">
                                    <span class="input-group-text bg-light">
                                        <i class="fas fa-phone"></i>
                                    </span>
                                </div>
                                <input type="number" name="tel" 
                                    class="form-control" 
                                    required="required"
                                    placeholder="Enter Phone Number"
                                    onfocus="this.parentElement.classList.add('shadow')"
                                    onblur="this.parentElement.classList.remove('shadow')"
                                    oninput="formatPhoneNumber(this)">
                                
                            </div>
                            <small class="form-text text-primary mt-1">
                                <i class="fas fa-info-circle mr-1"></i>
                                Enter Number Without Spaces
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <style>
        /* Custom styling for telephone inputs */
        #tel input,
        #tel select {
            transition: all 0.3s ease;
            border-left: 3px solid #ffc107;
        }
        
        #tel input:focus,
        #tel select:focus {
            border-color: #e0a800;
            box-shadow: 0 0 0 0.2rem rgba(255, 193, 7, 0.25);
        }
        
        #tel .input-group:focus-within .input-group-text {
            background-color: #ffc107;
            color: #212529;
        }
        
        #tel .input-group-text {
            transition: all 0.3s;
        }
        
        #tel .form-select {
            cursor: pointer;
        }
    </style>

    <script>
        // Phone number formatting and validation
        document.addEventListener('DOMContentLoaded', function() {
            const phoneInput = document.querySelector('#tel input[name="tel"]');
            const validIcon = document.getElementById('tel-valid-icon');
            
            if (phoneInput && validIcon) {
                phoneInput.addEventListener('input', function() {
                    // Show validation icon when number is long enough
                    if (this.value.length > 5) {
                        validIcon.classList.remove('d-none');
                        this.classList.add('is-valid');
                        validIcon.classList.add('animate__animated', 'animate__rubberBand');
                        setTimeout(() => validIcon.classList.remove('animate__animated', 'animate__rubberBand'), 1000);
                    } else {
                        validIcon.classList.add('d-none');
                        this.classList.remove('is-valid');
                    }
                });
            }
            
            // Format phone number with country code preview
            function formatPhoneNumber(input) {
                const countrySelect = document.querySelector('#tel select[name="countrycodetel"]');
                if (countrySelect && input.value.length > 0) {
                    const countryCode = countrySelect.value;
                    const formatted = `+${countryCode} ${input.value}`;
                    input.setAttribute('data-formatted', formatted);
                }
            }
            
            // Animate country code selector on change
            const countrySelect = document.querySelector('#tel select[name="countrycodetel"]');
            if (countrySelect) {
                countrySelect.addEventListener('change', function() {
                    this.classList.add('animate__animated', 'animate__tada');
                    setTimeout(() => this.classList.remove('animate__animated', 'animate__tada'), 1000);
                    
                    // Update phone number format if number exists
                    const phoneInput = document.querySelector('#tel input[name="tel"]');
                    if (phoneInput && phoneInput.value.length > 0) {
                        formatPhoneNumber(phoneInput);
                    }
                });
            }
        });
    </script>
    <?php
}