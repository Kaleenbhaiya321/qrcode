<?php
/**
 * LOCATION - Enhanced with animations and consistent UI
 */
if (qrcdr()->getConfig('location') == true) { ?>
    <div class="tab-pane fade <?php if ($getsection === "#location") echo "show active"; ?>" id="location">
        <div class="card border-success shadow-sm animate__animated animate__fadeIn">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0">
                    <i class="fas fa-map-marker-alt mr-2"></i>
                    <?php echo qrcdr()->getString('location'); ?>
                </h4>
            </div>
            <div class="card-body">
                <?php
                $google_api_key = qrcdr()->getConfig('google_api_key');
                if (!$google_api_key || $google_api_key == 'YOUR-API-KEY' || strlen($google_api_key) < 10) { ?>
                    <script src="<?php echo $relative; ?>js/ol/ol.js"></script>
                    <div class="alert alert-info animate__animated animate__fadeIn">
                        <i class="fas fa-info-circle mr-2"></i>
                       Search Address Or Drag Darker
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <div class="input-group animate__animated animate__pulse animate__delay-1s">
                                <div class="input-group-prepend">
                                    <span class="input-group-text bg-light">
                                        <i class="fas fa-search"></i>
                                    </span>
                                </div>
                                <input type="text" class="form-control venomaps-set-address nopreview" 
                                    placeholder="<?php echo qrcdr()->getString('search'); ?>"
                                    onfocus="this.parentElement.classList.add('shadow')"
                                    onblur="this.parentElement.classList.remove('shadow')">
                                <div class="input-group-append">
                                    <button class="btn btn-success venomaps-get-coordinates" type="button">
                                        <i class="fas fa-search-location"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="input-group animate__animated animate__pulse animate__delay-1s">
                                <div class="input-group-prepend">
                                    <span class="input-group-text bg-light">
                                        <i class="fas fa-latitude"></i>
                                    </span>
                                </div>
                                <input type="number" class="form-control venomaps-get-lat setinput-latlon no-validate" 
                                    value="" placeholder="<?php echo qrcdr()->getString('latitude'); ?>" 
                                    name="lat" step="0.001"
                                    onfocus="this.parentElement.classList.add('shadow')"
                                    onblur="this.parentElement.classList.remove('shadow')">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="input-group animate__animated animate__pulse animate__delay-1s">
                                <div class="input-group-prepend">
                                    <span class="input-group-text bg-light">
                                        <i class="fas fa-longitude"></i>
                                    </span>
                                </div>
                                <input type="number" class="form-control venomaps-get-lon setinput-latlon no-validate" 
                                    value="" placeholder="<?php echo qrcdr()->getString('longitude'); ?>" 
                                    name="lng" step="0.001"
                                    onfocus="this.parentElement.classList.add('shadow')"
                                    onblur="this.parentElement.classList.remove('shadow')">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div id="wpol-admin-map" data-lat="<?php echo qrcdr()->getConfig('lat'); ?>" 
                            data-lng="<?php echo qrcdr()->getConfig('lng'); ?>" 
                            class="venomap shadow-sm rounded animate__animated animate__fadeIn animate__delay-1s"
                            style="height: 350px; border: 1px solid #dee2e6;"></div>
                        <div style="display:none;">
                            <div class="wpol-infomarker" id="infomarker_admin"></div>
                        </div>
                    </div>
                    <?php
                } else { ?>
                    <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo qrcdr()->getConfig('google_api_key'); ?>&libraries=places"></script>
                    <div style="min-height:350px" class="mb-3">
                        <div id="latlong" class="row mb-3">
                            <div class="col-md-6">
                                <div class="input-group animate__animated animate__pulse animate__delay-1s">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text bg-light">
                                            <i class="fas fa-search"></i>
                                        </span>
                                    </div>
                                    <input id="pac-input" class="form-control nopreview" 
                                        type="text" placeholder="<?php echo qrcdr()->getString('search'); ?>"
                                        onfocus="this.parentElement.classList.add('shadow')"
                                        onblur="this.parentElement.classList.remove('shadow')">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group animate__animated animate__pulse animate__delay-1s">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text bg-light">
                                            <i class="fas fa-latitude"></i>
                                        </span>
                                    </div>
                                    <input type="number" id="latbox" placeholder="<?php echo qrcdr()->getString('latitude'); ?>" 
                                        class="form-control" name="lat" step="0.1"
                                        onfocus="this.parentElement.classList.add('shadow')"
                                        onblur="this.parentElement.classList.remove('shadow')">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group animate__animated animate__pulse animate__delay-1s">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text bg-light">
                                            <i class="fas fa-longitude"></i>
                                        </span>
                                    </div>
                                    <input type="number" id="lngbox" placeholder="<?php echo qrcdr()->getString('longitude'); ?>" 
                                        class="form-control" name="lng" step="0.1"
                                        onfocus="this.parentElement.classList.add('shadow')"
                                        onblur="this.parentElement.classList.remove('shadow')">
                                </div>
                            </div>
                        </div>
                        <div id="map-canvas" data-lat="<?php echo qrcdr()->getConfig('lat'); ?>" 
                            data-lng="<?php echo qrcdr()->getConfig('lng'); ?>"
                            class="shadow-sm rounded animate__animated animate__fadeIn animate__delay-1s"
                            style="height: 350px; border: 1px solid #dee2e6;"></div>
                    </div>
                    <?php
                } ?>
            </div>
        </div>
    </div>

    <style>
        /* Custom styling for location inputs */
        #location input {
            transition: all 0.3s ease;
            border-left: 3px solid #28a745;
        }
        
        #location input:focus {
            border-color: #218838;
            box-shadow: 0 0 0 0.2rem rgba(40, 167, 69, 0.25);
        }
        
        #location .input-group:focus-within .input-group-text {
            background-color: #28a745;
            color: white;
        }
        
        #location .venomap,
        #location #map-canvas {
            transition: all 0.3s ease;
        }
        
        #location .venomap:hover,
        #location #map-canvas:hover {
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15) !important;
        }
        
        #location .alert {
            border-left: 3px solid #17a2b8;
        }
    </style>

    <script>
        // Animation for map interaction
        document.addEventListener('DOMContentLoaded', function() {
            const mapElement = document.querySelector('#location .venomap') || 
                              document.querySelector('#location #map-canvas');
            
            if (mapElement) {
                mapElement.addEventListener('click', function() {
                    this.classList.add('animate__animated', 'animate__pulse');
                    setTimeout(() => this.classList.remove('animate__animated', 'animate__pulse'), 1000);
                });
            }
            
            // Animation for coordinate inputs when they change
            const latInput = document.querySelector('#location input[name="lat"]');
            const lngInput = document.querySelector('#location input[name="lng"]');
            
            if (latInput && lngInput) {
                latInput.addEventListener('change', function() {
                    this.classList.add('animate__animated', 'animate__flash');
                    setTimeout(() => this.classList.remove('animate__animated', 'animate__flash'), 1000);
                });
                
                lngInput.addEventListener('change', function() {
                    this.classList.add('animate__animated', 'animate__flash');
                    setTimeout(() => this.classList.remove('animate__animated', 'animate__flash'), 1000);
                });
            }
        });
    </script>
    <?php
}