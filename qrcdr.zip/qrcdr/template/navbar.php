<style>
/* Navbar Styles */
.navbar {
        background: linear-gradient(135deg, #1a2980 0%, #26d0ce 100%);
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    padding: 0.8rem 1rem;
    position: relative;
    z-index: 1000;
    transition: all 0.3s ease;
}

.navbar::before {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 3px;
    background: linear-gradient(90deg, #ff8a00, #e52e71, #1a2980);
    background-size: 200% 100%;
    animation: gradientFlow 8s ease infinite;
}

@keyframes gradientFlow {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}

.navbar-brand {
    font-weight: 700;
    font-size: 1.5rem;
    background: linear-gradient(to right, #fff 0%, #26d0ce 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    transition: all 0.3s ease;
}

.navbar-nav {
    gap: 0.5rem;
}

.nav-link {
    color: rgba(255, 255, 255, 0.9) !important;
    font-weight: 500;
    padding: 0.5rem 1rem !important;
    border-radius: 4px;
    position: relative;
    transition: all 0.3s ease;
    margin: 0 0.1rem;
}

.nav-link:hover {
    color: white !important;
    background: rgba(255, 255, 255, 0.15);
    transform: translateY(-2px);
}

.nav-link::before {
    content: '';
    position: absolute;
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
    width: 0;
    height: 2px;
    background: white;
    transition: width 0.3s ease;
}

.nav-link:hover::before {
    width: 70%;
}

/* Dropdown Styles */
.dropdown-menu {
    background: rgba(26, 41, 128, 0.95) !important;
    border: none !important;
    border-radius: 8px !important;
    padding: 0.5rem 0 !important;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
    transform-origin: top center;
    animation: fadeInDropdown 0.3s ease forwards;
    opacity: 0;
    margin-top: 8px !important;
}

@keyframes fadeInDropdown {
    from {
        opacity: 0;
        transform: translateY(10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.dropdown-item {
    color: rgba(255, 255, 255, 0.8) !important;
    padding: 0.5rem 1.5rem !important;
    transition: all 0.2s ease;
    position: relative;
}

.dropdown-item:hover {
    color: white !important;
    background: rgba(255, 255, 255, 0.1) !important;
    padding-left: 2rem !important;
}

.dropdown-item::before {
    content: '?';
    position: absolute;
    left: 0.8rem;
    opacity: 0;
    transition: all 0.2s ease;
}

.dropdown-item:hover::before {
    opacity: 1;
    left: 1rem;
}

/* Show dropdown on hover */
.nav-item.dropdown:hover .dropdown-menu {
    display: block;
    opacity: 1;
}

/* Toggler animation */
.navbar-toggler {
    border: none !important;
    padding: 0.5rem !important;
}

.navbar-toggler:focus {
    box-shadow: none !important;
}

.navbar-toggler-icon {
    background-image: none !important;
    position: relative;
    width: 24px;
    height: 2px;
    background: white;
    transition: all 0.3s ease;
}

.navbar-toggler-icon::before,
.navbar-toggler-icon::after {
    content: '';
    position: absolute;
    width: 24px;
    height: 2px;
    background: white;
    left: 0;
    transition: all 0.3s ease;
}

.navbar-toggler-icon::before {
    transform: translateY(-6px);
}

.navbar-toggler-icon::after {
    transform: translateY(6px);
}

.navbar-toggler[aria-expanded="true"] .navbar-toggler-icon {
    background: transparent;
}

.navbar-toggler[aria-expanded="true"] .navbar-toggler-icon::before {
    transform: rotate(45deg);
}

.navbar-toggler[aria-expanded="true"] .navbar-toggler-icon::after {
    transform: rotate(-45deg);
}

/* Responsive adjustments */
@media (max-width: 991.98px) {
    .navbar-collapse {
        background: rgba(26, 41, 128, 0.98);
        padding: 1rem;
        border-radius: 8px;
        margin-top: 10px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
    }
    
    .nav-item {
        margin: 0.3rem 0;
    }
    
    .dropdown-menu {
        background: rgba(20, 35, 120, 0.95) !important;
        margin-left: 1rem !important;
        width: calc(100% - 2rem);
    }
}
</style>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#qrcdrNavbar" aria-controls="qrcdrNavbar" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="qrcdrNavbar">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#">
                        <i class="fas fa-home me-1"></i> Home
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">
                        <i class="fas fa-link me-1"></i> Link 1
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">
                        <i class="fas fa-cog me-1"></i> Link 2
                    </a>
                </li>
                
                <?php echo qrcdr()->langMenu('menu'); ?>
                
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-chevron-circle-down me-1"></i> Test Menu
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="#"><i class="fas fa-rocket me-2"></i> Test 1</a></li>
                        <li><a class="dropdown-item" href="#"><i class="fas fa-cog me-2"></i> Test 2</a></li>
                        <li><a class="dropdown-item" href="#"><i class="fas fa-chart-line me-2"></i> Test 3</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="#"><i class="fas fa-star me-2"></i> Test 4</a></li>
                    </ul>
                </li>
            </ul>
            
            <!-- Search form (optional) -->
            <form class="d-flex ms-auto">
                <div class="input-group">
                    <input class="form-control" type="search" placeholder="Search..." aria-label="Search">
                    <button class="btn btn-outline-light" type="submit">
                        <i class="fas fa-search"></i>
                    </button>
                </div>
            </form>
        </div>
    </div>
</nav>

<!-- Font Awesome for icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>