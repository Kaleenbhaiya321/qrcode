<div class="sidebar-container py-4 px-3 mb-4 rounded">
    <div class="sidebar-header mb-3">
        <h3 class="text-white font-weight-bold border-bottom pb-2">Additional Resources</h3>
    </div>
    <div class="sidebar-content">
        <div class="sidebar-item bg-white p-3 mb-3 rounded shadow-sm">
            <h5 class="text-primary font-weight-bold">Premium QR Code Features</h5>
            <p class="text-primary mb-2">Upgrade to unlock advanced customization options and analytics tracking.</p>
            <a href="#" class="btn btn-sm btn-primary">Learn More</a>
        </div>
        
        <div class="sidebar-item bg-white p-3 mb-3 rounded shadow-sm">
            <h5 class="text-primary font-weight-bold">Need Help?</h5>
            <p class="text-primary mb-2">Visit our comprehensive documentation or contact our support team.</p>
            <a href="#" class="btn btn-sm btn-outline-primary">Support Center</a>
        </div>
        
        <div class="sidebar-item bg-white p-3 rounded shadow-sm">
            <h5 class="text-primary font-weight-bold">API Access</h5>
            <p class="text-primary mb-2">Integrate QR code generation directly into your applications.</p>
            <a href="#" class="btn btn-sm btn-outline-primary">Developer Docs</a>
        </div>
    </div>
    
    <div class="sidebar-footer mt-3 pt-3 border-top border-light">
        <small class="text-white-50 d-block">Customize this section in <code>template/sidebar.php</code></small>
        <small class="text-white-50">Remove this file if not needed</small>
    </div>
</div>

<style>
    .sidebar-container {
        background: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(5px);
        border: 1px solid rgba(255, 255, 255, 0.2);
    }
    .sidebar-item {
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    .sidebar-item:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1) !important;
    }
    .text-primary {
        color: #1a2980 !important;
    }
    .btn-outline-primary {
        border-color: #1a2980;
        color: #1a2980;
    }
    .btn-outline-primary:hover {
        background-color: #1a2980;
        color: white;
    }
</style>