<style>
/* Header Styles */
.header-slider {
    background: linear-gradient(135deg, #1a2980 0%, #26d0ce 100%);
    height: 300px;
    position: relative;
    overflow: hidden;
}

.overlay-gradient {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(to right, rgba(0,0,0,0.3) 0%, rgba(0,0,0,0) 100%);
    z-index: 1;
}

.slider-container {
    height: 100%;
    position: relative;
    z-index: 2;
}

.slide {
    position: absolute;
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    opacity: 0;
    transition: all 1s ease-in-out;
    transform: translateY(20px);
    padding: 0 15px;
}

.slide.active {
    opacity: 1;
    transform: translateY(0);
}

.slide-content {
    max-width: 800px;
    color: white;
    text-shadow: 0 2px 5px rgba(0,0,0,0.3);
}

.display-1 {
    font-weight: 700;
    margin-bottom: 1rem;
    background: linear-gradient(to right, #fff 0%, #c9f6ff 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    animation: textGlow 3s ease-in-out infinite alternate;
}

@keyframes textGlow {
    from { text-shadow: 0 0 10px rgba(255,255,255,0.3); }
    to { text-shadow: 0 0 20px rgba(255,255,255,0.7); }
}

.slide p {
    font-size: 1.2rem;
    line-height: 1.6;
    margin-bottom: 1.5rem;
    animation: fadeInUp 1s ease forwards;
}

.btn-primary {
    background-color: rgba(255,255,255,0.2);
    border: 2px solid white;
    border-radius: 50px;
    padding: 0.75rem 2rem;
    font-weight: 600;
    letter-spacing: 0.5px;
    transition: all 0.3s ease;
    animation: pulse 2s infinite;
}

.btn-primary:hover {
    background-color: white;
    color: #1a2980 !important;
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

@keyframes pulse {
    0% { transform: scale(1); }
    50% { transform: scale(1.05); }
    100% { transform: scale(1); }
}

.slider-dots {
    position: absolute;
    bottom: 20px;
    left: 50%;
    transform: translateX(-50%);
    display: flex;
    z-index: 3;
}

.dot {
    width: 12px;
    height: 12px;
    border-radius: 50%;
    background: rgba(255,255,255,0.5);
    margin: 0 5px;
    cursor: pointer;
    transition: all 0.3s ease;
}

.dot.active {
    background: white;
    transform: scale(1.2);
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
</style>

<div class="header-slider position-relative">
  <div class="overlay-gradient"></div>
  <div class="container slider-container">
    <!-- Slide 1 -->
    <div class="slide active">
      <div class="slide-content">
        <h1 class="display-1">QR Code Generator</h1>
        <p>Create stunning QR codes in seconds.<br>Perfect for businesses, marketing, and personal use.</p>
        <p><a href="#" class="btn btn-primary btn-lg shadow" role="button">Get Started &raquo;</a></p>
      </div>
    </div>
    
    <!-- Slide 2 -->
    <div class="slide">
      <div class="slide-content">
        <h1 class="display-1">Custom Designs</h1>
        <p>Personalize your QR codes with colors,<br>logos and unique patterns.</p>
        <p><a href="#" class="btn btn-primary btn-lg shadow" role="button">Learn More &raquo;</a></p>
      </div>
    </div>
    
    <!-- Slide 3 -->
    <div class="slide">
      <div class="slide-content">
        <h1 class="display-1">Track & Analyze</h1>
        <p>Monitor scans and get valuable insights<br>about your audience engagement.</p>
        <p><a href="#" class="btn btn-primary btn-lg shadow" role="button">See Analytics &raquo;</a></p>
      </div>
    </div>
  </div>
  
  <!-- Slider dots -->
  <div class="slider-dots">
    <div class="dot active" data-slide="0"></div>
    <div class="dot" data-slide="1"></div>
    <div class="dot" data-slide="2"></div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const slides = document.querySelectorAll('.slide');
    const dots = document.querySelectorAll('.dot');
    let currentSlide = 0;
    const slideInterval = 5000; // 5 seconds
    
    // Function to change slide
    function goToSlide(n) {
        slides[currentSlide].classList.remove('active');
        dots[currentSlide].classList.remove('active');
        currentSlide = (n + slides.length) % slides.length;
        slides[currentSlide].classList.add('active');
        dots[currentSlide].classList.add('active');
    }
    
    // Auto-rotate slides
    let slideTimer = setInterval(() => goToSlide(currentSlide + 1), slideInterval);
    
    // Pause on hover
    const slider = document.querySelector('.header-slider');
    slider.addEventListener('mouseenter', () => clearInterval(slideTimer));
    slider.addEventListener('mouseleave', () => {
        slideTimer = setInterval(() => goToSlide(currentSlide + 1), slideInterval);
    });
    
    // Dot navigation
    dots.forEach((dot, index) => {
        dot.addEventListener('click', () => {
            clearInterval(slideTimer);
            goToSlide(index);
            slideTimer = setInterval(() => goToSlide(currentSlide + 1), slideInterval);
        });
    });
});
</script>