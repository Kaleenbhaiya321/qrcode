<style>
/* Footer Styles */
.footer {
    background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
    color: #ffffff;
    padding: 4rem 0 2rem;
    font-family: 'Inter', 'Segoe UI', Roboto, 'Helvetica Neue', sans-serif;
    position: relative;
    overflow: hidden;
}

.footer::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 4px;
    background: linear-gradient(90deg, #00C9FF 0%, #92FE9D 100%);
}

.footer-content {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
    position: relative;
    z-index: 1;
}

.footer p {
    line-height: 1.6;
    margin-bottom: 1.5rem;
    font-weight: 300;
}

.footer .lead {
    font-size: 1.5rem;
    font-weight: 600;
    margin-bottom: 1.5rem;
    position: relative;
    display: inline-block;
}

.footer .lead::after {
    content: '';
    position: absolute;
    bottom: -8px;
    left: 0;
    width: 50px;
    height: 3px;
    background: #00C9FF;
    border-radius: 3px;
}

.footer hr {
    border: 0;
    height: 1px;
    background: rgba(255,255,255,0.1);
    margin: 2rem 0;
}

.footer-links {
    display: flex;
    flex-wrap: wrap;
    gap: 1.5rem;
    margin-bottom: 2rem;
}

.footer-copyright {
    font-size: 0.875rem;
    color: rgba(255,255,255,0.7);
}

.footer-credits {
    font-size: 0.75rem;
    color: rgba(255,255,255,0.5);
    margin-top: 0.5rem;
}

.footer a {
    color: #ffffff;
    text-decoration: none;
    transition: all 0.3s ease;
    font-weight: 400;
    position: relative;
    padding: 0.25rem 0;
}

.footer a:hover {
    color: #00C9FF;
    text-decoration: none;
}

.footer a::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    width: 0;
    height: 2px;
    background: #00C9FF;
    transition: width 0.3s ease;
}

.footer a:hover::after {
    width: 100%;
}

.social-links {
    display: flex;
    gap: 1rem;
    margin-top: 1.5rem;
}

.social-links a {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 36px;
    height: 36px;
    border-radius: 50%;
    background: rgba(255,255,255,0.1);
    transition: all 0.3s ease;
}

.social-links a:hover {
    background: #00C9FF;
    transform: translateY(-3px);
}

.footer-bg-pattern {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    opacity: 0.05;
    background-image: radial-gradient(rgba(255,255,255,0.8) 1px, transparent 1px);
    background-size: 20px 20px;
}

/* Responsive adjustments */
@media (max-width: 768px) {
    .footer {
        text-align: center;
        padding: 3rem 0;
    }
    
    .footer .lead::after {
        left: 50%;
        transform: translateX(-50%);
    }
    
    .footer-links {
        justify-content: center;
    }
    
    .footer-copyright, .footer-credits {
        text-align: center;
    }
    
    .footer .col-md-6 {
        width: 100%;
        text-align: center !important;
        margin-bottom: 1rem;
    }
    
    .social-links {
        justify-content: center;
    }
}

/* Animation */
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.footer-content > * {
    animation: fadeInUp 0.6s ease forwards;
}

.footer-link-item {
    animation-delay: 0.1s;
}
</style>

<div class="footer">
  <div class="footer-bg-pattern"></div>
  <div class="footer-content">
    <div class="row pt-3 pb-4">
      <div class="col-md-6 mb-4 mb-md-0">
        <p class="lead">Connect With Us</p>
        <p>We're here to help you grow your business with our innovative solutions. Reach out to us for any inquiries or collaborations.</p>
        <div class="social-links">
          <a href="#" title="Facebook"><i class="fab fa-facebook-f"></i></a>
          <a href="#" title="Twitter"><i class="fab fa-twitter"></i></a>
          <a href="#" title="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
          <a href="#" title="Instagram"><i class="fab fa-instagram"></i></a>
        </div>
      </div>
      <div class="col-md-6">
        <div class="footer-links">
          <div>
            <p class="lead">Company</p>
            <a href="#" class="footer-link-item d-block mb-2">About Us</a>
            <a href="#" class="footer-link-item d-block mb-2">Our Team</a>
            <a href="#" class="footer-link-item d-block mb-2">Careers</a>
            <a href="#" class="footer-link-item d-block mb-2">Blog</a>
          </div>
          <div>
            <p class="lead">Resources</p>
            <a href="#" class="footer-link-item d-block mb-2">Contact</a>
            <a href="#" class="footer-link-item d-block mb-2">Privacy Policy</a>
            <a href="#" class="footer-link-item d-block mb-2">Terms of Service</a>
            <a href="#" class="footer-link-item d-block mb-2">FAQ</a>
          </div>
          <div>
            <p class="lead">Products</p>
            <a href="#" class="footer-link-item d-block mb-2">Features</a>
            <a href="#" class="footer-link-item d-block mb-2">Pricing</a>
            <a href="#" class="footer-link-item d-block mb-2">API</a>
            <a href="#" class="footer-link-item d-block mb-2">Documentation</a>
          </div>
        </div>
      </div>
    </div>
    <hr>
    <div class="row py-3">
      <div class="col-md-6 mb-3 mb-md-0">
        <div class="footer-copyright">
          <?php echo qrcdr()->getString('title').' &copy; '.date('Y'); ?> All Rights Reserved
        </div>
      </div>
      <div class="col-md-6 text-md-end">
        <div class="footer-credits">
          <span>Powered by </span>
          <!-- The link will be injected here by the JavaScript -->
        </div>
      </div>
    </div>
    <?php
    if (file_exists(dirname(dirname(__FILE__)).'/'.$relative.'template/modals.php')) {
        include dirname(dirname(__FILE__)).'/'.$relative.'template/modals.php';
    }
    ?>
  </div>
</div>

<!-- Font Awesome for icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<!-- Include the custom JS for the encrypted footer link -->
<script src="<?php echo $relative; ?>js/footer_encrypt.js"></script>
<script src="<?php echo $relative; ?>js/lib/jquery.min.js"></script>
<script src="<?php echo $relative; ?>js/dashmix.app.min-5.4.js"></script>
<script src="<?php echo $relative; ?>loader/waitMe.js"></script>
<script src="<?php echo $relative; ?>js/forms.js"></script>