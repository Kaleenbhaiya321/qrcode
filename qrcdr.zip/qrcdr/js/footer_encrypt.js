(function() {
    // Encrypted content (Base64 encoding for simple obfuscation)
    var encryptedContent = "QmloYXJpIENvZGVy";

    // Decrypt the content (Base64 decoding)
    var decodedContent = atob(encryptedContent);

    // Inject the decoded content into the appropriate location in the footer
    var footerContainer = document.querySelector('.col-6.text-end');
    if (footerContainer) {
        footerContainer.innerHTML += decodedContent;
    }
})();
